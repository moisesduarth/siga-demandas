<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-26 00:36:18 --> Severity: Notice --> Undefined index: Nome_Usuario /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php 20
INFO - 2024-10-26 00:36:18 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:36:18 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:36:18 --> Final output sent to browser
DEBUG - 2024-10-26 00:36:18 --> Total execution time: 0.1168
ERROR - 2024-10-26 00:38:23 --> Severity: Notice --> Undefined index: Nome_Usuario /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php 20
INFO - 2024-10-26 00:38:23 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:38:23 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:38:23 --> Final output sent to browser
DEBUG - 2024-10-26 00:38:23 --> Total execution time: 0.0926
ERROR - 2024-10-26 00:38:51 --> Severity: Notice --> Undefined index: Nome_Usuario /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php 20
INFO - 2024-10-26 00:38:51 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:38:51 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:38:51 --> Final output sent to browser
DEBUG - 2024-10-26 00:38:51 --> Total execution time: 0.1127
INFO - 2024-10-26 00:41:45 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:41:45 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:41:45 --> Final output sent to browser
DEBUG - 2024-10-26 00:41:45 --> Total execution time: 0.1195
INFO - 2024-10-26 00:41:50 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:41:50 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:41:50 --> Final output sent to browser
DEBUG - 2024-10-26 00:41:50 --> Total execution time: 0.0766
INFO - 2024-10-26 00:41:53 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/add.php
INFO - 2024-10-26 00:41:53 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:41:53 --> Final output sent to browser
DEBUG - 2024-10-26 00:41:53 --> Total execution time: 0.0656
INFO - 2024-10-26 00:42:01 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:01 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:01 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:01 --> Total execution time: 0.0644
INFO - 2024-10-26 00:42:07 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/add.php
INFO - 2024-10-26 00:42:07 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:07 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:07 --> Total execution time: 0.0709
INFO - 2024-10-26 00:42:10 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:10 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:10 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:10 --> Total execution time: 0.0636
INFO - 2024-10-26 00:42:12 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:12 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:12 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:12 --> Total execution time: 0.0742
INFO - 2024-10-26 00:42:13 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:13 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:13 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:13 --> Total execution time: 0.0718
INFO - 2024-10-26 00:42:15 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:15 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:15 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:15 --> Total execution time: 0.0762
INFO - 2024-10-26 00:42:16 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/add.php
INFO - 2024-10-26 00:42:16 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:16 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:16 --> Total execution time: 0.0630
INFO - 2024-10-26 00:42:25 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:25 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:25 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:25 --> Total execution time: 0.0658
INFO - 2024-10-26 00:42:28 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:28 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:28 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:28 --> Total execution time: 0.0749
INFO - 2024-10-26 00:42:32 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/add.php
INFO - 2024-10-26 00:42:32 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:32 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:32 --> Total execution time: 0.0688
INFO - 2024-10-26 00:42:46 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:46 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:46 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:46 --> Total execution time: 0.0657
INFO - 2024-10-26 00:42:49 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:49 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:49 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:49 --> Total execution time: 0.0726
INFO - 2024-10-26 00:42:50 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:50 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:50 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:50 --> Total execution time: 0.0694
INFO - 2024-10-26 00:42:50 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:50 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:50 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:50 --> Total execution time: 0.0710
INFO - 2024-10-26 00:42:51 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:51 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:51 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:51 --> Total execution time: 0.0828
INFO - 2024-10-26 00:42:53 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:53 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:53 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:53 --> Total execution time: 0.0739
INFO - 2024-10-26 00:42:53 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:42:53 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:53 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:53 --> Total execution time: 0.0699
INFO - 2024-10-26 00:42:55 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/add.php
INFO - 2024-10-26 00:42:55 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:55 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:55 --> Total execution time: 0.0856
INFO - 2024-10-26 00:42:57 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 00:42:57 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:57 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:57 --> Total execution time: 0.0703
INFO - 2024-10-26 00:42:58 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/add.php
INFO - 2024-10-26 00:42:58 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:42:58 --> Final output sent to browser
DEBUG - 2024-10-26 00:42:58 --> Total execution time: 0.0626
INFO - 2024-10-26 00:43:00 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:43:00 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:43:00 --> Final output sent to browser
DEBUG - 2024-10-26 00:43:00 --> Total execution time: 0.0774
ERROR - 2024-10-26 00:45:39 --> Severity: Notice --> Undefined index: Data_Lancamento /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php 40
INFO - 2024-10-26 00:45:39 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:45:39 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:45:39 --> Final output sent to browser
DEBUG - 2024-10-26 00:45:39 --> Total execution time: 0.0995
INFO - 2024-10-26 00:46:05 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:46:05 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:05 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:05 --> Total execution time: 0.1198
INFO - 2024-10-26 00:46:16 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 00:46:16 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:16 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:16 --> Total execution time: 0.0869
INFO - 2024-10-26 00:46:22 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 00:46:22 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:22 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:22 --> Total execution time: 0.0906
INFO - 2024-10-26 00:46:25 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/add.php
INFO - 2024-10-26 00:46:25 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:25 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:25 --> Total execution time: 0.0687
INFO - 2024-10-26 00:46:26 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/instituicoes/index.php
INFO - 2024-10-26 00:46:26 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:26 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:26 --> Total execution time: 0.0790
INFO - 2024-10-26 00:46:26 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 00:46:26 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:26 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:26 --> Total execution time: 0.0753
INFO - 2024-10-26 00:46:28 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 00:46:28 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:28 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:28 --> Total execution time: 0.0729
INFO - 2024-10-26 00:46:30 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/demandas/pendentes.php
INFO - 2024-10-26 00:46:30 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:30 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:30 --> Total execution time: 0.0678
INFO - 2024-10-26 00:46:38 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 00:46:38 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:46:38 --> Final output sent to browser
DEBUG - 2024-10-26 00:46:38 --> Total execution time: 0.0738
INFO - 2024-10-26 00:59:20 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 00:59:20 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 00:59:20 --> Final output sent to browser
DEBUG - 2024-10-26 00:59:20 --> Total execution time: 0.1384
INFO - 2024-10-26 00:35:12 --> Config Class Initialized
INFO - 2024-10-26 00:35:12 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:35:12 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:35:12 --> Utf8 Class Initialized
INFO - 2024-10-26 00:35:12 --> URI Class Initialized
INFO - 2024-10-26 00:35:12 --> Router Class Initialized
INFO - 2024-10-26 00:35:12 --> Output Class Initialized
INFO - 2024-10-26 00:35:12 --> Security Class Initialized
DEBUG - 2024-10-26 00:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:35:12 --> Input Class Initialized
INFO - 2024-10-26 00:35:12 --> Language Class Initialized
INFO - 2024-10-26 00:35:12 --> Loader Class Initialized
DEBUG - 2024-10-26 00:35:12 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:35:12 --> Helper loaded: security_helper
INFO - 2024-10-26 00:35:12 --> Helper loaded: form_helper
INFO - 2024-10-26 00:35:12 --> Helper loaded: url_helper
INFO - 2024-10-26 00:35:12 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:35:12 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:35:12 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:35:12 --> Database Driver Class Initialized
INFO - 2024-10-26 00:35:12 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:35:12 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:35:12 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:35:12 --> Email Class Initialized
INFO - 2024-10-26 00:35:12 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:35:12 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:35:12 --> Helper loaded: language_helper
INFO - 2024-10-26 00:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:35:12 --> Model Class Initialized
INFO - 2024-10-26 00:35:12 --> Helper loaded: date_helper
INFO - 2024-10-26 00:35:12 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:35:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:35:12 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:35:12 --> Migrations Class Initialized
INFO - 2024-10-26 00:35:12 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:35:12 --> Database Forge Class Initialized
INFO - 2024-10-26 00:35:12 --> Controller Class Initialized
INFO - 2024-10-26 00:35:12 --> Model Class Initialized
INFO - 2024-10-26 00:35:12 --> Model Class Initialized
INFO - 2024-10-26 00:35:12 --> Model Class Initialized
INFO - 2024-10-26 00:35:12 --> Model Class Initialized
INFO - 2024-10-26 01:35:12 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:35:12 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:35:12 --> Final output sent to browser
DEBUG - 2024-10-26 01:35:12 --> Total execution time: 0.1639
INFO - 2024-10-26 00:35:15 --> Config Class Initialized
INFO - 2024-10-26 00:35:15 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:35:15 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:35:15 --> Utf8 Class Initialized
INFO - 2024-10-26 00:35:15 --> URI Class Initialized
INFO - 2024-10-26 00:35:15 --> Router Class Initialized
INFO - 2024-10-26 00:35:15 --> Output Class Initialized
INFO - 2024-10-26 00:35:15 --> Security Class Initialized
DEBUG - 2024-10-26 00:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:35:15 --> Input Class Initialized
INFO - 2024-10-26 00:35:15 --> Language Class Initialized
ERROR - 2024-10-26 00:35:15 --> 404 Page Not Found: Lancamento/estorno
INFO - 2024-10-26 00:35:37 --> Config Class Initialized
INFO - 2024-10-26 00:35:37 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:35:37 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:35:37 --> Utf8 Class Initialized
INFO - 2024-10-26 00:35:37 --> URI Class Initialized
INFO - 2024-10-26 00:35:37 --> Router Class Initialized
INFO - 2024-10-26 00:35:37 --> Output Class Initialized
INFO - 2024-10-26 00:35:37 --> Security Class Initialized
DEBUG - 2024-10-26 00:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:35:37 --> Input Class Initialized
INFO - 2024-10-26 00:35:37 --> Language Class Initialized
INFO - 2024-10-26 00:35:37 --> Loader Class Initialized
DEBUG - 2024-10-26 00:35:37 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:35:37 --> Helper loaded: security_helper
INFO - 2024-10-26 00:35:37 --> Helper loaded: form_helper
INFO - 2024-10-26 00:35:37 --> Helper loaded: url_helper
INFO - 2024-10-26 00:35:37 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:35:37 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:35:37 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:35:37 --> Database Driver Class Initialized
INFO - 2024-10-26 00:35:37 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:35:37 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:35:37 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:35:37 --> Email Class Initialized
INFO - 2024-10-26 00:35:37 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:35:37 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:35:37 --> Helper loaded: language_helper
INFO - 2024-10-26 00:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:35:37 --> Model Class Initialized
INFO - 2024-10-26 00:35:37 --> Helper loaded: date_helper
INFO - 2024-10-26 00:35:37 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:35:37 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:35:37 --> Migrations Class Initialized
INFO - 2024-10-26 00:35:37 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:35:37 --> Database Forge Class Initialized
INFO - 2024-10-26 00:35:37 --> Controller Class Initialized
INFO - 2024-10-26 00:35:37 --> Model Class Initialized
INFO - 2024-10-26 00:35:37 --> Model Class Initialized
INFO - 2024-10-26 00:35:37 --> Model Class Initialized
INFO - 2024-10-26 00:35:37 --> Model Class Initialized
INFO - 2024-10-26 01:35:37 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:35:37 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:35:37 --> Final output sent to browser
DEBUG - 2024-10-26 01:35:37 --> Total execution time: 0.1393
INFO - 2024-10-26 00:38:52 --> Config Class Initialized
INFO - 2024-10-26 00:38:52 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:38:52 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:38:52 --> Utf8 Class Initialized
INFO - 2024-10-26 00:38:52 --> URI Class Initialized
INFO - 2024-10-26 00:38:52 --> Router Class Initialized
INFO - 2024-10-26 00:38:52 --> Output Class Initialized
INFO - 2024-10-26 00:38:52 --> Security Class Initialized
DEBUG - 2024-10-26 00:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:38:52 --> Input Class Initialized
INFO - 2024-10-26 00:38:52 --> Language Class Initialized
ERROR - 2024-10-26 00:38:52 --> 404 Page Not Found: Lancamento/estorno
INFO - 2024-10-26 00:38:55 --> Config Class Initialized
INFO - 2024-10-26 00:38:55 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:38:55 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:38:55 --> Utf8 Class Initialized
INFO - 2024-10-26 00:38:55 --> URI Class Initialized
INFO - 2024-10-26 00:38:55 --> Router Class Initialized
INFO - 2024-10-26 00:38:55 --> Output Class Initialized
INFO - 2024-10-26 00:38:55 --> Security Class Initialized
DEBUG - 2024-10-26 00:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:38:55 --> Input Class Initialized
INFO - 2024-10-26 00:38:55 --> Language Class Initialized
ERROR - 2024-10-26 00:38:55 --> 404 Page Not Found: Lancamento/estorno
INFO - 2024-10-26 00:38:55 --> Config Class Initialized
INFO - 2024-10-26 00:38:55 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:38:55 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:38:55 --> Utf8 Class Initialized
INFO - 2024-10-26 00:38:55 --> URI Class Initialized
INFO - 2024-10-26 00:38:55 --> Router Class Initialized
INFO - 2024-10-26 00:38:55 --> Output Class Initialized
INFO - 2024-10-26 00:38:55 --> Security Class Initialized
DEBUG - 2024-10-26 00:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:38:55 --> Input Class Initialized
INFO - 2024-10-26 00:38:55 --> Language Class Initialized
INFO - 2024-10-26 00:38:55 --> Loader Class Initialized
DEBUG - 2024-10-26 00:38:55 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:38:55 --> Helper loaded: security_helper
INFO - 2024-10-26 00:38:55 --> Helper loaded: form_helper
INFO - 2024-10-26 00:38:55 --> Helper loaded: url_helper
INFO - 2024-10-26 00:38:55 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:38:55 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:38:55 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:38:55 --> Database Driver Class Initialized
INFO - 2024-10-26 00:38:56 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:38:56 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:38:56 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:38:56 --> Email Class Initialized
INFO - 2024-10-26 00:38:56 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:38:56 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:38:56 --> Helper loaded: language_helper
INFO - 2024-10-26 00:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:38:56 --> Model Class Initialized
INFO - 2024-10-26 00:38:56 --> Helper loaded: date_helper
INFO - 2024-10-26 00:38:56 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:38:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:38:56 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:38:56 --> Migrations Class Initialized
INFO - 2024-10-26 00:38:56 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:38:56 --> Database Forge Class Initialized
INFO - 2024-10-26 00:38:56 --> Controller Class Initialized
INFO - 2024-10-26 00:38:56 --> Model Class Initialized
INFO - 2024-10-26 00:38:56 --> Model Class Initialized
INFO - 2024-10-26 00:38:56 --> Model Class Initialized
INFO - 2024-10-26 00:38:56 --> Model Class Initialized
INFO - 2024-10-26 01:38:56 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:38:56 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:38:56 --> Final output sent to browser
DEBUG - 2024-10-26 01:38:56 --> Total execution time: 0.1337
INFO - 2024-10-26 00:38:59 --> Config Class Initialized
INFO - 2024-10-26 00:38:59 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:38:59 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:38:59 --> Utf8 Class Initialized
INFO - 2024-10-26 00:38:59 --> URI Class Initialized
INFO - 2024-10-26 00:38:59 --> Router Class Initialized
INFO - 2024-10-26 00:38:59 --> Output Class Initialized
INFO - 2024-10-26 00:38:59 --> Security Class Initialized
DEBUG - 2024-10-26 00:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:38:59 --> Input Class Initialized
INFO - 2024-10-26 00:38:59 --> Language Class Initialized
ERROR - 2024-10-26 00:38:59 --> 404 Page Not Found: Lancamento/estorno
INFO - 2024-10-26 00:39:20 --> Config Class Initialized
INFO - 2024-10-26 00:39:20 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:39:20 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:39:20 --> Utf8 Class Initialized
INFO - 2024-10-26 00:39:20 --> URI Class Initialized
INFO - 2024-10-26 00:39:20 --> Router Class Initialized
INFO - 2024-10-26 00:39:20 --> Output Class Initialized
INFO - 2024-10-26 00:39:20 --> Security Class Initialized
DEBUG - 2024-10-26 00:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:39:20 --> Input Class Initialized
INFO - 2024-10-26 00:39:20 --> Language Class Initialized
INFO - 2024-10-26 00:39:20 --> Loader Class Initialized
DEBUG - 2024-10-26 00:39:20 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:39:20 --> Helper loaded: security_helper
INFO - 2024-10-26 00:39:20 --> Helper loaded: form_helper
INFO - 2024-10-26 00:39:20 --> Helper loaded: url_helper
INFO - 2024-10-26 00:39:20 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:39:20 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:39:20 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:39:20 --> Database Driver Class Initialized
INFO - 2024-10-26 00:39:20 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:39:20 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:39:20 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:39:20 --> Email Class Initialized
INFO - 2024-10-26 00:39:20 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:39:20 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:39:20 --> Helper loaded: language_helper
INFO - 2024-10-26 00:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:39:20 --> Model Class Initialized
INFO - 2024-10-26 00:39:20 --> Helper loaded: date_helper
INFO - 2024-10-26 00:39:20 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:39:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:39:20 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:39:20 --> Migrations Class Initialized
INFO - 2024-10-26 00:39:20 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:39:20 --> Database Forge Class Initialized
INFO - 2024-10-26 00:39:20 --> Controller Class Initialized
INFO - 2024-10-26 00:39:20 --> Model Class Initialized
INFO - 2024-10-26 00:39:20 --> Model Class Initialized
INFO - 2024-10-26 00:39:20 --> Model Class Initialized
INFO - 2024-10-26 00:39:20 --> Model Class Initialized
INFO - 2024-10-26 00:39:23 --> Config Class Initialized
INFO - 2024-10-26 00:39:23 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:39:23 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:39:23 --> Utf8 Class Initialized
INFO - 2024-10-26 00:39:23 --> URI Class Initialized
INFO - 2024-10-26 00:39:23 --> Router Class Initialized
INFO - 2024-10-26 00:39:23 --> Output Class Initialized
INFO - 2024-10-26 00:39:23 --> Security Class Initialized
DEBUG - 2024-10-26 00:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:39:23 --> Input Class Initialized
INFO - 2024-10-26 00:39:23 --> Language Class Initialized
INFO - 2024-10-26 00:39:23 --> Loader Class Initialized
DEBUG - 2024-10-26 00:39:23 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:39:23 --> Helper loaded: security_helper
INFO - 2024-10-26 00:39:23 --> Helper loaded: form_helper
INFO - 2024-10-26 00:39:23 --> Helper loaded: url_helper
INFO - 2024-10-26 00:39:23 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:39:23 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:39:23 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:39:23 --> Database Driver Class Initialized
INFO - 2024-10-26 00:39:23 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:39:23 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:39:23 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:39:23 --> Email Class Initialized
INFO - 2024-10-26 00:39:23 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:39:23 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:39:23 --> Helper loaded: language_helper
INFO - 2024-10-26 00:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:39:23 --> Model Class Initialized
INFO - 2024-10-26 00:39:23 --> Helper loaded: date_helper
INFO - 2024-10-26 00:39:23 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:39:23 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:39:23 --> Migrations Class Initialized
INFO - 2024-10-26 00:39:23 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:39:23 --> Database Forge Class Initialized
INFO - 2024-10-26 00:39:23 --> Controller Class Initialized
INFO - 2024-10-26 00:39:23 --> Model Class Initialized
INFO - 2024-10-26 00:39:23 --> Model Class Initialized
INFO - 2024-10-26 00:39:23 --> Model Class Initialized
INFO - 2024-10-26 00:39:23 --> Model Class Initialized
INFO - 2024-10-26 01:39:23 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:39:23 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:39:23 --> Final output sent to browser
DEBUG - 2024-10-26 01:39:23 --> Total execution time: 0.0824
INFO - 2024-10-26 00:39:51 --> Config Class Initialized
INFO - 2024-10-26 00:39:51 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:39:51 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:39:51 --> Utf8 Class Initialized
INFO - 2024-10-26 00:39:51 --> URI Class Initialized
INFO - 2024-10-26 00:39:51 --> Router Class Initialized
INFO - 2024-10-26 00:39:51 --> Output Class Initialized
INFO - 2024-10-26 00:39:51 --> Security Class Initialized
DEBUG - 2024-10-26 00:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:39:51 --> Input Class Initialized
INFO - 2024-10-26 00:39:51 --> Language Class Initialized
INFO - 2024-10-26 00:39:51 --> Loader Class Initialized
DEBUG - 2024-10-26 00:39:51 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:39:51 --> Helper loaded: security_helper
INFO - 2024-10-26 00:39:51 --> Helper loaded: form_helper
INFO - 2024-10-26 00:39:51 --> Helper loaded: url_helper
INFO - 2024-10-26 00:39:51 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:39:51 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:39:51 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:39:51 --> Database Driver Class Initialized
INFO - 2024-10-26 00:39:51 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:39:51 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:39:51 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:39:51 --> Email Class Initialized
INFO - 2024-10-26 00:39:51 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:39:51 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:39:51 --> Helper loaded: language_helper
INFO - 2024-10-26 00:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:39:51 --> Model Class Initialized
INFO - 2024-10-26 00:39:51 --> Helper loaded: date_helper
INFO - 2024-10-26 00:39:51 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:39:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:39:51 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:39:51 --> Migrations Class Initialized
INFO - 2024-10-26 00:39:51 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:39:51 --> Database Forge Class Initialized
INFO - 2024-10-26 00:39:51 --> Controller Class Initialized
INFO - 2024-10-26 00:39:51 --> Model Class Initialized
INFO - 2024-10-26 00:39:51 --> Model Class Initialized
INFO - 2024-10-26 00:39:51 --> Model Class Initialized
INFO - 2024-10-26 00:39:51 --> Model Class Initialized
INFO - 2024-10-26 01:39:51 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:39:51 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:39:51 --> Final output sent to browser
DEBUG - 2024-10-26 01:39:51 --> Total execution time: 0.0975
INFO - 2024-10-26 00:39:53 --> Config Class Initialized
INFO - 2024-10-26 00:39:53 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:39:53 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:39:53 --> Utf8 Class Initialized
INFO - 2024-10-26 00:39:53 --> URI Class Initialized
INFO - 2024-10-26 00:39:53 --> Router Class Initialized
INFO - 2024-10-26 00:39:53 --> Output Class Initialized
INFO - 2024-10-26 00:39:53 --> Security Class Initialized
DEBUG - 2024-10-26 00:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:39:53 --> Input Class Initialized
INFO - 2024-10-26 00:39:53 --> Language Class Initialized
INFO - 2024-10-26 00:39:53 --> Loader Class Initialized
DEBUG - 2024-10-26 00:39:53 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:39:53 --> Helper loaded: security_helper
INFO - 2024-10-26 00:39:53 --> Helper loaded: form_helper
INFO - 2024-10-26 00:39:53 --> Helper loaded: url_helper
INFO - 2024-10-26 00:39:53 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:39:53 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:39:53 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:39:53 --> Database Driver Class Initialized
INFO - 2024-10-26 00:39:53 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:39:53 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:39:53 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:39:53 --> Email Class Initialized
INFO - 2024-10-26 00:39:53 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:39:53 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:39:53 --> Helper loaded: language_helper
INFO - 2024-10-26 00:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:39:53 --> Model Class Initialized
INFO - 2024-10-26 00:39:53 --> Helper loaded: date_helper
INFO - 2024-10-26 00:39:53 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:39:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:39:53 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:39:53 --> Migrations Class Initialized
INFO - 2024-10-26 00:39:53 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:39:53 --> Database Forge Class Initialized
INFO - 2024-10-26 00:39:53 --> Controller Class Initialized
INFO - 2024-10-26 00:39:53 --> Model Class Initialized
INFO - 2024-10-26 00:39:53 --> Model Class Initialized
INFO - 2024-10-26 00:39:53 --> Model Class Initialized
INFO - 2024-10-26 00:39:53 --> Model Class Initialized
INFO - 2024-10-26 00:39:55 --> Config Class Initialized
INFO - 2024-10-26 00:39:55 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:39:55 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:39:55 --> Utf8 Class Initialized
INFO - 2024-10-26 00:39:55 --> URI Class Initialized
INFO - 2024-10-26 00:39:55 --> Router Class Initialized
INFO - 2024-10-26 00:39:55 --> Output Class Initialized
INFO - 2024-10-26 00:39:55 --> Security Class Initialized
DEBUG - 2024-10-26 00:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:39:55 --> Input Class Initialized
INFO - 2024-10-26 00:39:55 --> Language Class Initialized
INFO - 2024-10-26 00:39:55 --> Loader Class Initialized
DEBUG - 2024-10-26 00:39:55 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:39:55 --> Helper loaded: security_helper
INFO - 2024-10-26 00:39:55 --> Helper loaded: form_helper
INFO - 2024-10-26 00:39:55 --> Helper loaded: url_helper
INFO - 2024-10-26 00:39:55 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:39:55 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:39:55 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:39:55 --> Database Driver Class Initialized
INFO - 2024-10-26 00:39:55 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:39:55 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:39:55 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:39:55 --> Email Class Initialized
INFO - 2024-10-26 00:39:55 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:39:55 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:39:55 --> Helper loaded: language_helper
INFO - 2024-10-26 00:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:39:55 --> Model Class Initialized
INFO - 2024-10-26 00:39:55 --> Helper loaded: date_helper
INFO - 2024-10-26 00:39:55 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:39:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:39:55 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:39:55 --> Migrations Class Initialized
INFO - 2024-10-26 00:39:55 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:39:55 --> Database Forge Class Initialized
INFO - 2024-10-26 00:39:55 --> Controller Class Initialized
INFO - 2024-10-26 00:39:55 --> Model Class Initialized
INFO - 2024-10-26 00:39:55 --> Model Class Initialized
INFO - 2024-10-26 00:39:55 --> Model Class Initialized
INFO - 2024-10-26 00:39:55 --> Model Class Initialized
INFO - 2024-10-26 01:39:55 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:39:55 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:39:55 --> Final output sent to browser
DEBUG - 2024-10-26 01:39:55 --> Total execution time: 0.0952
INFO - 2024-10-26 00:39:57 --> Config Class Initialized
INFO - 2024-10-26 00:39:57 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:39:57 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:39:57 --> Utf8 Class Initialized
INFO - 2024-10-26 00:39:57 --> URI Class Initialized
INFO - 2024-10-26 00:39:57 --> Router Class Initialized
INFO - 2024-10-26 00:39:57 --> Output Class Initialized
INFO - 2024-10-26 00:39:57 --> Security Class Initialized
DEBUG - 2024-10-26 00:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:39:57 --> Input Class Initialized
INFO - 2024-10-26 00:39:57 --> Language Class Initialized
INFO - 2024-10-26 00:39:57 --> Loader Class Initialized
DEBUG - 2024-10-26 00:39:57 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:39:57 --> Helper loaded: security_helper
INFO - 2024-10-26 00:39:57 --> Helper loaded: form_helper
INFO - 2024-10-26 00:39:57 --> Helper loaded: url_helper
INFO - 2024-10-26 00:39:57 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:39:57 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:39:57 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:39:57 --> Database Driver Class Initialized
INFO - 2024-10-26 00:39:57 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:39:57 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:39:57 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:39:57 --> Email Class Initialized
INFO - 2024-10-26 00:39:57 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:39:57 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:39:57 --> Helper loaded: language_helper
INFO - 2024-10-26 00:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:39:57 --> Model Class Initialized
INFO - 2024-10-26 00:39:57 --> Helper loaded: date_helper
INFO - 2024-10-26 00:39:57 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:39:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:39:57 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:39:57 --> Migrations Class Initialized
INFO - 2024-10-26 00:39:57 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:39:57 --> Database Forge Class Initialized
INFO - 2024-10-26 00:39:57 --> Controller Class Initialized
INFO - 2024-10-26 00:39:57 --> Model Class Initialized
INFO - 2024-10-26 00:39:57 --> Model Class Initialized
INFO - 2024-10-26 00:39:57 --> Model Class Initialized
INFO - 2024-10-26 00:39:57 --> Model Class Initialized
INFO - 2024-10-26 01:39:57 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:39:57 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:39:57 --> Final output sent to browser
DEBUG - 2024-10-26 01:39:57 --> Total execution time: 0.0751
INFO - 2024-10-26 00:40:57 --> Config Class Initialized
INFO - 2024-10-26 00:40:57 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:40:57 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:40:57 --> Utf8 Class Initialized
INFO - 2024-10-26 00:40:57 --> URI Class Initialized
INFO - 2024-10-26 00:40:57 --> Router Class Initialized
INFO - 2024-10-26 00:40:57 --> Output Class Initialized
INFO - 2024-10-26 00:40:57 --> Security Class Initialized
DEBUG - 2024-10-26 00:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:40:57 --> Input Class Initialized
INFO - 2024-10-26 00:40:57 --> Language Class Initialized
INFO - 2024-10-26 00:40:57 --> Loader Class Initialized
DEBUG - 2024-10-26 00:40:57 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:40:57 --> Helper loaded: security_helper
INFO - 2024-10-26 00:40:57 --> Helper loaded: form_helper
INFO - 2024-10-26 00:40:57 --> Helper loaded: url_helper
INFO - 2024-10-26 00:40:57 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:40:57 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:40:57 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:40:57 --> Database Driver Class Initialized
INFO - 2024-10-26 00:40:57 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:40:57 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:40:57 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:40:57 --> Email Class Initialized
INFO - 2024-10-26 00:40:57 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:40:57 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:40:57 --> Helper loaded: language_helper
INFO - 2024-10-26 00:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:40:57 --> Model Class Initialized
INFO - 2024-10-26 00:40:57 --> Helper loaded: date_helper
INFO - 2024-10-26 00:40:57 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:40:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:40:57 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:40:57 --> Migrations Class Initialized
INFO - 2024-10-26 00:40:57 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:40:57 --> Database Forge Class Initialized
INFO - 2024-10-26 00:40:57 --> Controller Class Initialized
INFO - 2024-10-26 00:40:57 --> Model Class Initialized
INFO - 2024-10-26 00:40:57 --> Model Class Initialized
INFO - 2024-10-26 00:40:57 --> Model Class Initialized
INFO - 2024-10-26 00:40:57 --> Model Class Initialized
INFO - 2024-10-26 00:40:59 --> Config Class Initialized
INFO - 2024-10-26 00:40:59 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:40:59 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:40:59 --> Utf8 Class Initialized
INFO - 2024-10-26 00:40:59 --> URI Class Initialized
INFO - 2024-10-26 00:40:59 --> Router Class Initialized
INFO - 2024-10-26 00:40:59 --> Output Class Initialized
INFO - 2024-10-26 00:40:59 --> Security Class Initialized
DEBUG - 2024-10-26 00:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:40:59 --> Input Class Initialized
INFO - 2024-10-26 00:40:59 --> Language Class Initialized
INFO - 2024-10-26 00:40:59 --> Loader Class Initialized
DEBUG - 2024-10-26 00:40:59 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:40:59 --> Helper loaded: security_helper
INFO - 2024-10-26 00:40:59 --> Helper loaded: form_helper
INFO - 2024-10-26 00:40:59 --> Helper loaded: url_helper
INFO - 2024-10-26 00:40:59 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:40:59 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:40:59 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:40:59 --> Database Driver Class Initialized
INFO - 2024-10-26 00:40:59 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:40:59 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:40:59 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:40:59 --> Email Class Initialized
INFO - 2024-10-26 00:40:59 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:40:59 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:40:59 --> Helper loaded: language_helper
INFO - 2024-10-26 00:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:40:59 --> Model Class Initialized
INFO - 2024-10-26 00:40:59 --> Helper loaded: date_helper
INFO - 2024-10-26 00:40:59 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:40:59 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:40:59 --> Migrations Class Initialized
INFO - 2024-10-26 00:40:59 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:40:59 --> Database Forge Class Initialized
INFO - 2024-10-26 00:40:59 --> Controller Class Initialized
INFO - 2024-10-26 00:40:59 --> Model Class Initialized
INFO - 2024-10-26 00:40:59 --> Model Class Initialized
INFO - 2024-10-26 00:40:59 --> Model Class Initialized
INFO - 2024-10-26 00:40:59 --> Model Class Initialized
INFO - 2024-10-26 01:40:59 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:40:59 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:40:59 --> Final output sent to browser
DEBUG - 2024-10-26 01:40:59 --> Total execution time: 0.0829
INFO - 2024-10-26 00:42:21 --> Config Class Initialized
INFO - 2024-10-26 00:42:21 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:42:21 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:42:21 --> Utf8 Class Initialized
INFO - 2024-10-26 00:42:21 --> URI Class Initialized
INFO - 2024-10-26 00:42:21 --> Router Class Initialized
INFO - 2024-10-26 00:42:21 --> Output Class Initialized
INFO - 2024-10-26 00:42:21 --> Security Class Initialized
DEBUG - 2024-10-26 00:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:42:21 --> Input Class Initialized
INFO - 2024-10-26 00:42:21 --> Language Class Initialized
INFO - 2024-10-26 00:42:21 --> Loader Class Initialized
DEBUG - 2024-10-26 00:42:21 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:42:21 --> Helper loaded: security_helper
INFO - 2024-10-26 00:42:21 --> Helper loaded: form_helper
INFO - 2024-10-26 00:42:21 --> Helper loaded: url_helper
INFO - 2024-10-26 00:42:21 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:42:21 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:42:21 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:42:21 --> Database Driver Class Initialized
INFO - 2024-10-26 00:42:21 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:42:21 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:42:21 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:42:21 --> Email Class Initialized
INFO - 2024-10-26 00:42:21 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:42:21 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:42:21 --> Helper loaded: language_helper
INFO - 2024-10-26 00:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:42:21 --> Model Class Initialized
INFO - 2024-10-26 00:42:21 --> Helper loaded: date_helper
INFO - 2024-10-26 00:42:21 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:42:21 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:42:21 --> Migrations Class Initialized
INFO - 2024-10-26 00:42:21 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:42:21 --> Database Forge Class Initialized
INFO - 2024-10-26 00:42:21 --> Controller Class Initialized
INFO - 2024-10-26 00:42:21 --> Model Class Initialized
INFO - 2024-10-26 00:42:21 --> Model Class Initialized
INFO - 2024-10-26 00:42:21 --> Model Class Initialized
INFO - 2024-10-26 00:42:21 --> Model Class Initialized
INFO - 2024-10-26 01:42:21 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:42:21 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:42:21 --> Final output sent to browser
DEBUG - 2024-10-26 01:42:21 --> Total execution time: 0.0881
INFO - 2024-10-26 00:42:22 --> Config Class Initialized
INFO - 2024-10-26 00:42:22 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:42:22 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:42:22 --> Utf8 Class Initialized
INFO - 2024-10-26 00:42:22 --> URI Class Initialized
INFO - 2024-10-26 00:42:22 --> Router Class Initialized
INFO - 2024-10-26 00:42:22 --> Output Class Initialized
INFO - 2024-10-26 00:42:22 --> Security Class Initialized
DEBUG - 2024-10-26 00:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:42:22 --> Input Class Initialized
INFO - 2024-10-26 00:42:22 --> Language Class Initialized
INFO - 2024-10-26 00:42:22 --> Loader Class Initialized
DEBUG - 2024-10-26 00:42:22 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:42:22 --> Helper loaded: security_helper
INFO - 2024-10-26 00:42:22 --> Helper loaded: form_helper
INFO - 2024-10-26 00:42:22 --> Helper loaded: url_helper
INFO - 2024-10-26 00:42:22 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:42:22 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:42:22 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:42:22 --> Database Driver Class Initialized
INFO - 2024-10-26 00:42:22 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:42:22 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:42:22 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:42:22 --> Email Class Initialized
INFO - 2024-10-26 00:42:22 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:42:22 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:42:22 --> Helper loaded: language_helper
INFO - 2024-10-26 00:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:42:22 --> Model Class Initialized
INFO - 2024-10-26 00:42:22 --> Helper loaded: date_helper
INFO - 2024-10-26 00:42:22 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:42:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:42:22 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:42:22 --> Migrations Class Initialized
INFO - 2024-10-26 00:42:22 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:42:22 --> Database Forge Class Initialized
INFO - 2024-10-26 00:42:22 --> Controller Class Initialized
INFO - 2024-10-26 00:42:22 --> Model Class Initialized
INFO - 2024-10-26 00:42:22 --> Model Class Initialized
INFO - 2024-10-26 00:42:22 --> Model Class Initialized
INFO - 2024-10-26 00:42:22 --> Model Class Initialized
ERROR - 2024-10-26 00:42:22 --> Severity: Notice --> Undefined index: Tipo_Lancamento /Applications/MAMP/htdocs/credito/application/controllers/Lancamento.php 167
ERROR - 2024-10-26 00:42:22 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/credito/system/database/DB_driver.php 1476
ERROR - 2024-10-26 00:42:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, `Tipo_Lancamento`, `ID_User_Create`, `ID_User_Update`, `ID_Lancamento_Estorna' at line 1 - Invalid query: INSERT INTO `lancamento` (0, `Tipo_Lancamento`, `ID_User_Create`, `ID_User_Update`, `ID_Lancamento_Estornado`) VALUES (Array, 1, '1', '1', '5')
INFO - 2024-10-26 00:42:22 --> Language file loaded: language/portuguese/db_lang.php
INFO - 2024-10-26 00:43:07 --> Config Class Initialized
INFO - 2024-10-26 00:43:07 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:43:07 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:43:07 --> Utf8 Class Initialized
INFO - 2024-10-26 00:43:07 --> URI Class Initialized
INFO - 2024-10-26 00:43:07 --> Router Class Initialized
INFO - 2024-10-26 00:43:07 --> Output Class Initialized
INFO - 2024-10-26 00:43:07 --> Security Class Initialized
DEBUG - 2024-10-26 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:43:07 --> Input Class Initialized
INFO - 2024-10-26 00:43:07 --> Language Class Initialized
INFO - 2024-10-26 00:43:07 --> Loader Class Initialized
DEBUG - 2024-10-26 00:43:07 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:43:07 --> Helper loaded: security_helper
INFO - 2024-10-26 00:43:07 --> Helper loaded: form_helper
INFO - 2024-10-26 00:43:07 --> Helper loaded: url_helper
INFO - 2024-10-26 00:43:07 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:43:07 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:43:07 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:43:07 --> Database Driver Class Initialized
INFO - 2024-10-26 00:43:07 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:43:07 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:43:07 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:43:07 --> Email Class Initialized
INFO - 2024-10-26 00:43:07 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:43:07 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:43:07 --> Helper loaded: language_helper
INFO - 2024-10-26 00:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:43:07 --> Model Class Initialized
INFO - 2024-10-26 00:43:07 --> Helper loaded: date_helper
INFO - 2024-10-26 00:43:07 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:43:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:43:07 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:43:07 --> Migrations Class Initialized
INFO - 2024-10-26 00:43:07 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:43:07 --> Database Forge Class Initialized
INFO - 2024-10-26 00:43:07 --> Controller Class Initialized
INFO - 2024-10-26 00:43:07 --> Model Class Initialized
INFO - 2024-10-26 00:43:07 --> Model Class Initialized
INFO - 2024-10-26 00:43:07 --> Model Class Initialized
INFO - 2024-10-26 00:43:07 --> Model Class Initialized
ERROR - 2024-10-26 00:43:07 --> Severity: Notice --> Undefined index: Motivo_Lancamento /Applications/MAMP/htdocs/credito/application/controllers/Lancamento.php 170
ERROR - 2024-10-26 00:43:07 --> Severity: Notice --> Undefined index: Valor_Lancamento /Applications/MAMP/htdocs/credito/application/controllers/Lancamento.php 171
ERROR - 2024-10-26 00:43:07 --> Severity: Notice --> Undefined index: Tipo_Lancamento /Applications/MAMP/htdocs/credito/application/controllers/Lancamento.php 172
ERROR - 2024-10-26 00:43:07 --> Query error: Column 'Valor_Lancamento' cannot be null - Invalid query: INSERT INTO `lancamento` (`Motivo_Lancamento`, `Valor_Lancamento`, `Tipo_Lancamento`, `ID_User_Create`, `ID_User_Update`, `ID_Lancamento_Estornado`, `Date_Created`, `Date_Updated`) VALUES ('Estorno de ', NULL, 1, '1', '1', '5', '2024-10-26 00:43:07', '2024-10-26 00:43:07')
INFO - 2024-10-26 00:43:07 --> Language file loaded: language/portuguese/db_lang.php
INFO - 2024-10-26 00:43:08 --> Config Class Initialized
INFO - 2024-10-26 00:43:08 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:43:08 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:43:08 --> Utf8 Class Initialized
INFO - 2024-10-26 00:43:08 --> URI Class Initialized
INFO - 2024-10-26 00:43:08 --> Router Class Initialized
INFO - 2024-10-26 00:43:08 --> Output Class Initialized
INFO - 2024-10-26 00:43:08 --> Security Class Initialized
DEBUG - 2024-10-26 00:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:43:08 --> Input Class Initialized
INFO - 2024-10-26 00:43:08 --> Language Class Initialized
INFO - 2024-10-26 00:43:08 --> Loader Class Initialized
DEBUG - 2024-10-26 00:43:08 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:43:08 --> Helper loaded: security_helper
INFO - 2024-10-26 00:43:08 --> Helper loaded: form_helper
INFO - 2024-10-26 00:43:08 --> Helper loaded: url_helper
INFO - 2024-10-26 00:43:08 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:43:08 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:43:08 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:43:08 --> Database Driver Class Initialized
INFO - 2024-10-26 00:43:08 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:43:08 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:43:08 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:43:08 --> Email Class Initialized
INFO - 2024-10-26 00:43:08 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:43:08 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:43:08 --> Helper loaded: language_helper
INFO - 2024-10-26 00:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:43:08 --> Model Class Initialized
INFO - 2024-10-26 00:43:08 --> Helper loaded: date_helper
INFO - 2024-10-26 00:43:08 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:43:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:43:08 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:43:08 --> Migrations Class Initialized
INFO - 2024-10-26 00:43:08 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:43:08 --> Database Forge Class Initialized
INFO - 2024-10-26 00:43:08 --> Controller Class Initialized
INFO - 2024-10-26 00:43:08 --> Model Class Initialized
INFO - 2024-10-26 00:43:08 --> Model Class Initialized
INFO - 2024-10-26 00:43:08 --> Model Class Initialized
INFO - 2024-10-26 00:43:08 --> Model Class Initialized
INFO - 2024-10-26 01:43:08 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:43:08 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:43:08 --> Final output sent to browser
DEBUG - 2024-10-26 01:43:08 --> Total execution time: 0.0740
INFO - 2024-10-26 00:43:10 --> Config Class Initialized
INFO - 2024-10-26 00:43:10 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:43:10 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:43:10 --> Utf8 Class Initialized
INFO - 2024-10-26 00:43:10 --> URI Class Initialized
INFO - 2024-10-26 00:43:10 --> Router Class Initialized
INFO - 2024-10-26 00:43:10 --> Output Class Initialized
INFO - 2024-10-26 00:43:10 --> Security Class Initialized
DEBUG - 2024-10-26 00:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:43:10 --> Input Class Initialized
INFO - 2024-10-26 00:43:10 --> Language Class Initialized
INFO - 2024-10-26 00:43:10 --> Loader Class Initialized
DEBUG - 2024-10-26 00:43:10 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:43:10 --> Helper loaded: security_helper
INFO - 2024-10-26 00:43:10 --> Helper loaded: form_helper
INFO - 2024-10-26 00:43:10 --> Helper loaded: url_helper
INFO - 2024-10-26 00:43:10 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:43:10 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:43:10 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:43:10 --> Database Driver Class Initialized
INFO - 2024-10-26 00:43:10 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:43:10 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:43:10 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:43:10 --> Email Class Initialized
INFO - 2024-10-26 00:43:10 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:43:10 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:43:10 --> Helper loaded: language_helper
INFO - 2024-10-26 00:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:43:10 --> Model Class Initialized
INFO - 2024-10-26 00:43:10 --> Helper loaded: date_helper
INFO - 2024-10-26 00:43:10 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:43:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:43:10 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:43:10 --> Migrations Class Initialized
INFO - 2024-10-26 00:43:10 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:43:10 --> Database Forge Class Initialized
INFO - 2024-10-26 00:43:10 --> Controller Class Initialized
INFO - 2024-10-26 00:43:10 --> Model Class Initialized
INFO - 2024-10-26 00:43:10 --> Model Class Initialized
INFO - 2024-10-26 00:43:10 --> Model Class Initialized
INFO - 2024-10-26 00:43:10 --> Model Class Initialized
ERROR - 2024-10-26 00:43:10 --> Severity: Notice --> Undefined index: Motivo_Lancamento /Applications/MAMP/htdocs/credito/application/controllers/Lancamento.php 170
ERROR - 2024-10-26 00:43:10 --> Severity: Notice --> Undefined index: Valor_Lancamento /Applications/MAMP/htdocs/credito/application/controllers/Lancamento.php 171
ERROR - 2024-10-26 00:43:10 --> Severity: Notice --> Undefined index: Tipo_Lancamento /Applications/MAMP/htdocs/credito/application/controllers/Lancamento.php 172
ERROR - 2024-10-26 00:43:10 --> Query error: Column 'Valor_Lancamento' cannot be null - Invalid query: INSERT INTO `lancamento` (`Motivo_Lancamento`, `Valor_Lancamento`, `Tipo_Lancamento`, `ID_User_Create`, `ID_User_Update`, `ID_Lancamento_Estornado`, `Date_Created`, `Date_Updated`) VALUES ('Estorno de ', NULL, 1, '1', '1', '4', '2024-10-26 00:43:10', '2024-10-26 00:43:10')
INFO - 2024-10-26 00:43:10 --> Language file loaded: language/portuguese/db_lang.php
INFO - 2024-10-26 00:44:51 --> Config Class Initialized
INFO - 2024-10-26 00:44:51 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:44:51 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:44:51 --> Utf8 Class Initialized
INFO - 2024-10-26 00:44:51 --> URI Class Initialized
INFO - 2024-10-26 00:44:51 --> Router Class Initialized
INFO - 2024-10-26 00:44:51 --> Output Class Initialized
INFO - 2024-10-26 00:44:51 --> Security Class Initialized
DEBUG - 2024-10-26 00:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:44:51 --> Input Class Initialized
INFO - 2024-10-26 00:44:51 --> Language Class Initialized
INFO - 2024-10-26 00:44:51 --> Loader Class Initialized
DEBUG - 2024-10-26 00:44:51 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:44:51 --> Helper loaded: security_helper
INFO - 2024-10-26 00:44:51 --> Helper loaded: form_helper
INFO - 2024-10-26 00:44:51 --> Helper loaded: url_helper
INFO - 2024-10-26 00:44:51 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:44:51 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:44:51 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:44:51 --> Database Driver Class Initialized
INFO - 2024-10-26 00:44:51 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:44:51 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:44:51 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:44:51 --> Email Class Initialized
INFO - 2024-10-26 00:44:51 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:44:51 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:44:51 --> Helper loaded: language_helper
INFO - 2024-10-26 00:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:44:51 --> Model Class Initialized
INFO - 2024-10-26 00:44:51 --> Helper loaded: date_helper
INFO - 2024-10-26 00:44:51 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:44:51 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:44:51 --> Migrations Class Initialized
INFO - 2024-10-26 00:44:51 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:44:51 --> Database Forge Class Initialized
INFO - 2024-10-26 00:44:51 --> Controller Class Initialized
INFO - 2024-10-26 00:44:51 --> Model Class Initialized
INFO - 2024-10-26 00:44:51 --> Model Class Initialized
INFO - 2024-10-26 00:44:51 --> Model Class Initialized
INFO - 2024-10-26 00:44:51 --> Model Class Initialized
INFO - 2024-10-26 00:45:28 --> Config Class Initialized
INFO - 2024-10-26 00:45:28 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:45:28 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:45:28 --> Utf8 Class Initialized
INFO - 2024-10-26 00:45:28 --> URI Class Initialized
INFO - 2024-10-26 00:45:28 --> Router Class Initialized
INFO - 2024-10-26 00:45:28 --> Output Class Initialized
INFO - 2024-10-26 00:45:28 --> Security Class Initialized
DEBUG - 2024-10-26 00:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:45:28 --> Input Class Initialized
INFO - 2024-10-26 00:45:28 --> Language Class Initialized
INFO - 2024-10-26 00:45:28 --> Loader Class Initialized
DEBUG - 2024-10-26 00:45:28 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:45:28 --> Helper loaded: security_helper
INFO - 2024-10-26 00:45:28 --> Helper loaded: form_helper
INFO - 2024-10-26 00:45:28 --> Helper loaded: url_helper
INFO - 2024-10-26 00:45:28 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:45:28 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:45:28 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:45:28 --> Database Driver Class Initialized
INFO - 2024-10-26 00:45:28 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:45:28 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:45:28 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:45:28 --> Email Class Initialized
INFO - 2024-10-26 00:45:28 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:45:28 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:45:28 --> Helper loaded: language_helper
INFO - 2024-10-26 00:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:45:28 --> Model Class Initialized
INFO - 2024-10-26 00:45:28 --> Helper loaded: date_helper
INFO - 2024-10-26 00:45:28 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:45:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:45:28 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:45:28 --> Migrations Class Initialized
INFO - 2024-10-26 00:45:28 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:45:28 --> Database Forge Class Initialized
INFO - 2024-10-26 00:45:28 --> Controller Class Initialized
INFO - 2024-10-26 00:45:28 --> Model Class Initialized
INFO - 2024-10-26 00:45:28 --> Model Class Initialized
INFO - 2024-10-26 00:45:28 --> Model Class Initialized
INFO - 2024-10-26 00:45:28 --> Model Class Initialized
INFO - 2024-10-26 01:45:28 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:45:28 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:45:28 --> Final output sent to browser
DEBUG - 2024-10-26 01:45:28 --> Total execution time: 0.0836
INFO - 2024-10-26 00:45:29 --> Config Class Initialized
INFO - 2024-10-26 00:45:29 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:45:29 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:45:29 --> Utf8 Class Initialized
INFO - 2024-10-26 00:45:29 --> URI Class Initialized
INFO - 2024-10-26 00:45:29 --> Router Class Initialized
INFO - 2024-10-26 00:45:29 --> Output Class Initialized
INFO - 2024-10-26 00:45:29 --> Security Class Initialized
DEBUG - 2024-10-26 00:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:45:29 --> Input Class Initialized
INFO - 2024-10-26 00:45:29 --> Language Class Initialized
INFO - 2024-10-26 00:45:29 --> Loader Class Initialized
DEBUG - 2024-10-26 00:45:29 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:45:29 --> Helper loaded: security_helper
INFO - 2024-10-26 00:45:29 --> Helper loaded: form_helper
INFO - 2024-10-26 00:45:29 --> Helper loaded: url_helper
INFO - 2024-10-26 00:45:29 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:45:29 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:45:29 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:45:29 --> Database Driver Class Initialized
INFO - 2024-10-26 00:45:29 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:45:29 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:45:29 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:45:29 --> Email Class Initialized
INFO - 2024-10-26 00:45:29 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:45:29 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:45:29 --> Helper loaded: language_helper
INFO - 2024-10-26 00:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:45:29 --> Model Class Initialized
INFO - 2024-10-26 00:45:29 --> Helper loaded: date_helper
INFO - 2024-10-26 00:45:29 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:45:29 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:45:29 --> Migrations Class Initialized
INFO - 2024-10-26 00:45:29 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:45:29 --> Database Forge Class Initialized
INFO - 2024-10-26 00:45:29 --> Controller Class Initialized
INFO - 2024-10-26 00:45:29 --> Model Class Initialized
INFO - 2024-10-26 00:45:29 --> Model Class Initialized
INFO - 2024-10-26 00:45:29 --> Model Class Initialized
INFO - 2024-10-26 00:45:29 --> Model Class Initialized
INFO - 2024-10-26 01:45:29 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:45:29 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:45:29 --> Final output sent to browser
DEBUG - 2024-10-26 01:45:29 --> Total execution time: 0.0854
INFO - 2024-10-26 00:46:07 --> Config Class Initialized
INFO - 2024-10-26 00:46:07 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:46:07 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:46:07 --> Utf8 Class Initialized
INFO - 2024-10-26 00:46:07 --> URI Class Initialized
INFO - 2024-10-26 00:46:07 --> Router Class Initialized
INFO - 2024-10-26 00:46:07 --> Output Class Initialized
INFO - 2024-10-26 00:46:07 --> Security Class Initialized
DEBUG - 2024-10-26 00:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:46:07 --> Input Class Initialized
INFO - 2024-10-26 00:46:07 --> Language Class Initialized
INFO - 2024-10-26 00:46:07 --> Loader Class Initialized
DEBUG - 2024-10-26 00:46:07 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:46:07 --> Helper loaded: security_helper
INFO - 2024-10-26 00:46:07 --> Helper loaded: form_helper
INFO - 2024-10-26 00:46:07 --> Helper loaded: url_helper
INFO - 2024-10-26 00:46:07 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:46:07 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:46:07 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:46:07 --> Database Driver Class Initialized
INFO - 2024-10-26 00:46:07 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:46:07 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:46:07 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:46:07 --> Email Class Initialized
INFO - 2024-10-26 00:46:07 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:46:07 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:46:07 --> Helper loaded: language_helper
INFO - 2024-10-26 00:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:46:07 --> Model Class Initialized
INFO - 2024-10-26 00:46:07 --> Helper loaded: date_helper
INFO - 2024-10-26 00:46:07 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:46:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:46:07 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:46:07 --> Migrations Class Initialized
INFO - 2024-10-26 00:46:07 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:46:07 --> Database Forge Class Initialized
INFO - 2024-10-26 00:46:07 --> Controller Class Initialized
INFO - 2024-10-26 00:46:07 --> Model Class Initialized
INFO - 2024-10-26 00:46:07 --> Model Class Initialized
INFO - 2024-10-26 00:46:07 --> Model Class Initialized
INFO - 2024-10-26 00:46:07 --> Model Class Initialized
INFO - 2024-10-26 01:46:07 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:46:07 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:46:07 --> Final output sent to browser
DEBUG - 2024-10-26 01:46:07 --> Total execution time: 0.0930
INFO - 2024-10-26 00:46:09 --> Config Class Initialized
INFO - 2024-10-26 00:46:09 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:46:09 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:46:09 --> Utf8 Class Initialized
INFO - 2024-10-26 00:46:09 --> URI Class Initialized
INFO - 2024-10-26 00:46:09 --> Router Class Initialized
INFO - 2024-10-26 00:46:09 --> Output Class Initialized
INFO - 2024-10-26 00:46:09 --> Security Class Initialized
DEBUG - 2024-10-26 00:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:46:09 --> Input Class Initialized
INFO - 2024-10-26 00:46:09 --> Language Class Initialized
INFO - 2024-10-26 00:46:09 --> Loader Class Initialized
DEBUG - 2024-10-26 00:46:09 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:46:09 --> Helper loaded: security_helper
INFO - 2024-10-26 00:46:09 --> Helper loaded: form_helper
INFO - 2024-10-26 00:46:09 --> Helper loaded: url_helper
INFO - 2024-10-26 00:46:09 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:46:09 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:46:09 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:46:09 --> Database Driver Class Initialized
INFO - 2024-10-26 00:46:09 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:46:09 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:46:09 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:46:09 --> Email Class Initialized
INFO - 2024-10-26 00:46:09 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:46:09 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:46:09 --> Helper loaded: language_helper
INFO - 2024-10-26 00:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:46:09 --> Model Class Initialized
INFO - 2024-10-26 00:46:09 --> Helper loaded: date_helper
INFO - 2024-10-26 00:46:09 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:46:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:46:09 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:46:09 --> Migrations Class Initialized
INFO - 2024-10-26 00:46:09 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:46:09 --> Database Forge Class Initialized
INFO - 2024-10-26 00:46:09 --> Controller Class Initialized
INFO - 2024-10-26 00:46:09 --> Model Class Initialized
INFO - 2024-10-26 00:46:09 --> Model Class Initialized
INFO - 2024-10-26 00:46:09 --> Model Class Initialized
INFO - 2024-10-26 00:46:09 --> Model Class Initialized
INFO - 2024-10-26 00:46:11 --> Config Class Initialized
INFO - 2024-10-26 00:46:11 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:46:11 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:46:11 --> Utf8 Class Initialized
INFO - 2024-10-26 00:46:11 --> URI Class Initialized
INFO - 2024-10-26 00:46:11 --> Router Class Initialized
INFO - 2024-10-26 00:46:11 --> Output Class Initialized
INFO - 2024-10-26 00:46:11 --> Security Class Initialized
DEBUG - 2024-10-26 00:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:46:11 --> Input Class Initialized
INFO - 2024-10-26 00:46:11 --> Language Class Initialized
INFO - 2024-10-26 00:46:11 --> Loader Class Initialized
DEBUG - 2024-10-26 00:46:11 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:46:11 --> Helper loaded: security_helper
INFO - 2024-10-26 00:46:11 --> Helper loaded: form_helper
INFO - 2024-10-26 00:46:11 --> Helper loaded: url_helper
INFO - 2024-10-26 00:46:11 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:46:11 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:46:11 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:46:11 --> Database Driver Class Initialized
INFO - 2024-10-26 00:46:11 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:46:11 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:46:11 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:46:11 --> Email Class Initialized
INFO - 2024-10-26 00:46:11 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:46:11 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:46:11 --> Helper loaded: language_helper
INFO - 2024-10-26 00:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:46:11 --> Model Class Initialized
INFO - 2024-10-26 00:46:11 --> Helper loaded: date_helper
INFO - 2024-10-26 00:46:11 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:46:11 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:46:11 --> Migrations Class Initialized
INFO - 2024-10-26 00:46:11 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:46:11 --> Database Forge Class Initialized
INFO - 2024-10-26 00:46:11 --> Controller Class Initialized
INFO - 2024-10-26 00:46:11 --> Model Class Initialized
INFO - 2024-10-26 00:46:11 --> Model Class Initialized
INFO - 2024-10-26 00:46:11 --> Model Class Initialized
INFO - 2024-10-26 00:46:11 --> Model Class Initialized
INFO - 2024-10-26 01:46:11 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 01:46:11 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 01:46:11 --> Final output sent to browser
DEBUG - 2024-10-26 01:46:11 --> Total execution time: 0.0862
INFO - 2024-10-26 00:46:14 --> Config Class Initialized
INFO - 2024-10-26 00:46:14 --> Hooks Class Initialized
DEBUG - 2024-10-26 00:46:14 --> UTF-8 Support Enabled
INFO - 2024-10-26 00:46:14 --> Utf8 Class Initialized
INFO - 2024-10-26 00:46:14 --> URI Class Initialized
INFO - 2024-10-26 00:46:14 --> Router Class Initialized
INFO - 2024-10-26 00:46:14 --> Output Class Initialized
INFO - 2024-10-26 00:46:14 --> Security Class Initialized
DEBUG - 2024-10-26 00:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 00:46:14 --> Input Class Initialized
INFO - 2024-10-26 00:46:14 --> Language Class Initialized
INFO - 2024-10-26 00:46:14 --> Loader Class Initialized
DEBUG - 2024-10-26 00:46:14 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 00:46:14 --> Helper loaded: security_helper
INFO - 2024-10-26 00:46:14 --> Helper loaded: form_helper
INFO - 2024-10-26 00:46:14 --> Helper loaded: url_helper
INFO - 2024-10-26 00:46:14 --> Helper loaded: datetime_helper
INFO - 2024-10-26 00:46:14 --> Helper loaded: numbers_helper
INFO - 2024-10-26 00:46:14 --> Helper loaded: strings_helper
INFO - 2024-10-26 00:46:14 --> Database Driver Class Initialized
INFO - 2024-10-26 00:46:14 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 00:46:14 --> Pagination Class Initialized
DEBUG - 2024-10-26 00:46:14 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 00:46:14 --> Email Class Initialized
INFO - 2024-10-26 00:46:14 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 00:46:14 --> Helper loaded: cookie_helper
INFO - 2024-10-26 00:46:14 --> Helper loaded: language_helper
INFO - 2024-10-26 00:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 00:46:14 --> Model Class Initialized
INFO - 2024-10-26 00:46:14 --> Helper loaded: date_helper
INFO - 2024-10-26 00:46:14 --> Form Validation Class Initialized
DEBUG - 2024-10-26 00:46:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 00:46:14 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 00:46:14 --> Migrations Class Initialized
INFO - 2024-10-26 00:46:14 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 00:46:14 --> Database Forge Class Initialized
INFO - 2024-10-26 00:46:14 --> Controller Class Initialized
INFO - 2024-10-26 00:46:14 --> Model Class Initialized
INFO - 2024-10-26 00:46:14 --> Model Class Initialized
INFO - 2024-10-26 00:46:14 --> Model Class Initialized
INFO - 2024-10-26 00:46:14 --> Model Class Initialized
INFO - 2024-10-26 02:45:08 --> Config Class Initialized
INFO - 2024-10-26 02:45:08 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:45:08 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:45:08 --> Utf8 Class Initialized
INFO - 2024-10-26 02:45:08 --> URI Class Initialized
INFO - 2024-10-26 02:45:08 --> Router Class Initialized
INFO - 2024-10-26 02:45:08 --> Output Class Initialized
INFO - 2024-10-26 02:45:08 --> Security Class Initialized
DEBUG - 2024-10-26 02:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:45:08 --> Input Class Initialized
INFO - 2024-10-26 02:45:08 --> Language Class Initialized
INFO - 2024-10-26 02:45:08 --> Loader Class Initialized
DEBUG - 2024-10-26 02:45:08 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:45:08 --> Helper loaded: security_helper
INFO - 2024-10-26 02:45:08 --> Helper loaded: form_helper
INFO - 2024-10-26 02:45:08 --> Helper loaded: url_helper
INFO - 2024-10-26 02:45:08 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:45:08 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:45:08 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:45:08 --> Database Driver Class Initialized
INFO - 2024-10-26 02:45:08 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:45:08 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:45:08 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:45:08 --> Email Class Initialized
INFO - 2024-10-26 02:45:08 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:45:08 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:45:08 --> Helper loaded: language_helper
INFO - 2024-10-26 02:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:45:08 --> Model Class Initialized
INFO - 2024-10-26 02:45:08 --> Helper loaded: date_helper
INFO - 2024-10-26 02:45:08 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:45:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:45:08 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:45:08 --> Migrations Class Initialized
INFO - 2024-10-26 02:45:08 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:45:08 --> Database Forge Class Initialized
INFO - 2024-10-26 02:45:08 --> Controller Class Initialized
INFO - 2024-10-26 02:45:08 --> Model Class Initialized
INFO - 2024-10-26 02:45:08 --> Model Class Initialized
INFO - 2024-10-26 02:45:08 --> Model Class Initialized
INFO - 2024-10-26 02:45:08 --> Model Class Initialized
INFO - 2024-10-26 02:45:44 --> Config Class Initialized
INFO - 2024-10-26 02:45:44 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:45:44 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:45:44 --> Utf8 Class Initialized
INFO - 2024-10-26 02:45:44 --> URI Class Initialized
INFO - 2024-10-26 02:45:44 --> Router Class Initialized
INFO - 2024-10-26 02:45:44 --> Output Class Initialized
INFO - 2024-10-26 02:45:44 --> Security Class Initialized
DEBUG - 2024-10-26 02:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:45:44 --> Input Class Initialized
INFO - 2024-10-26 02:45:44 --> Language Class Initialized
INFO - 2024-10-26 02:45:44 --> Loader Class Initialized
DEBUG - 2024-10-26 02:45:44 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:45:44 --> Helper loaded: security_helper
INFO - 2024-10-26 02:45:44 --> Helper loaded: form_helper
INFO - 2024-10-26 02:45:44 --> Helper loaded: url_helper
INFO - 2024-10-26 02:45:44 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:45:44 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:45:44 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:45:44 --> Database Driver Class Initialized
INFO - 2024-10-26 02:45:44 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:45:44 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:45:44 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:45:44 --> Email Class Initialized
INFO - 2024-10-26 02:45:44 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:45:44 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:45:44 --> Helper loaded: language_helper
INFO - 2024-10-26 02:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:45:44 --> Model Class Initialized
INFO - 2024-10-26 02:45:44 --> Helper loaded: date_helper
INFO - 2024-10-26 02:45:44 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:45:44 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:45:44 --> Migrations Class Initialized
INFO - 2024-10-26 02:45:44 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:45:44 --> Database Forge Class Initialized
INFO - 2024-10-26 02:45:44 --> Controller Class Initialized
INFO - 2024-10-26 02:45:44 --> Model Class Initialized
INFO - 2024-10-26 02:45:44 --> Model Class Initialized
INFO - 2024-10-26 02:45:44 --> Model Class Initialized
INFO - 2024-10-26 02:45:44 --> Model Class Initialized
INFO - 2024-10-26 02:45:45 --> Config Class Initialized
INFO - 2024-10-26 02:45:45 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:45:45 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:45:45 --> Utf8 Class Initialized
INFO - 2024-10-26 02:45:45 --> URI Class Initialized
INFO - 2024-10-26 02:45:45 --> Router Class Initialized
INFO - 2024-10-26 02:45:45 --> Output Class Initialized
INFO - 2024-10-26 02:45:45 --> Security Class Initialized
DEBUG - 2024-10-26 02:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:45:46 --> Input Class Initialized
INFO - 2024-10-26 02:45:46 --> Language Class Initialized
INFO - 2024-10-26 02:45:46 --> Loader Class Initialized
DEBUG - 2024-10-26 02:45:46 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:45:46 --> Helper loaded: security_helper
INFO - 2024-10-26 02:45:46 --> Helper loaded: form_helper
INFO - 2024-10-26 02:45:46 --> Helper loaded: url_helper
INFO - 2024-10-26 02:45:46 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:45:46 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:45:46 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:45:46 --> Database Driver Class Initialized
INFO - 2024-10-26 02:45:46 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:45:46 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:45:46 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:45:46 --> Email Class Initialized
INFO - 2024-10-26 02:45:46 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:45:46 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:45:46 --> Helper loaded: language_helper
INFO - 2024-10-26 02:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:45:46 --> Model Class Initialized
INFO - 2024-10-26 02:45:46 --> Helper loaded: date_helper
INFO - 2024-10-26 02:45:46 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:45:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:45:46 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:45:46 --> Migrations Class Initialized
INFO - 2024-10-26 02:45:46 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:45:46 --> Database Forge Class Initialized
INFO - 2024-10-26 02:45:46 --> Controller Class Initialized
INFO - 2024-10-26 02:45:46 --> Model Class Initialized
INFO - 2024-10-26 02:45:46 --> Model Class Initialized
INFO - 2024-10-26 02:45:46 --> Model Class Initialized
INFO - 2024-10-26 02:45:46 --> Model Class Initialized
INFO - 2024-10-26 03:45:46 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:45:46 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
ERROR - 2024-10-26 03:45:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 108
ERROR - 2024-10-26 03:45:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 138
ERROR - 2024-10-26 03:45:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 545
INFO - 2024-10-26 03:45:46 --> Language file loaded: language/portuguese/profiler_lang.php
INFO - 2024-10-26 03:45:46 --> Profiler Class Initialized
INFO - 2024-10-26 03:45:46 --> Helper loaded: text_helper
INFO - 2024-10-26 03:45:46 --> Final output sent to browser
DEBUG - 2024-10-26 03:45:46 --> Total execution time: 0.0876
INFO - 2024-10-26 02:45:48 --> Config Class Initialized
INFO - 2024-10-26 02:45:48 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:45:48 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:45:48 --> Utf8 Class Initialized
INFO - 2024-10-26 02:45:48 --> URI Class Initialized
INFO - 2024-10-26 02:45:48 --> Router Class Initialized
INFO - 2024-10-26 02:45:48 --> Output Class Initialized
INFO - 2024-10-26 02:45:48 --> Security Class Initialized
DEBUG - 2024-10-26 02:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:45:48 --> Input Class Initialized
INFO - 2024-10-26 02:45:48 --> Language Class Initialized
INFO - 2024-10-26 02:45:48 --> Loader Class Initialized
DEBUG - 2024-10-26 02:45:48 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:45:48 --> Helper loaded: security_helper
INFO - 2024-10-26 02:45:48 --> Helper loaded: form_helper
INFO - 2024-10-26 02:45:48 --> Helper loaded: url_helper
INFO - 2024-10-26 02:45:48 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:45:48 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:45:48 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:45:48 --> Database Driver Class Initialized
INFO - 2024-10-26 02:45:48 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:45:48 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:45:48 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:45:48 --> Email Class Initialized
INFO - 2024-10-26 02:45:48 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:45:48 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:45:48 --> Helper loaded: language_helper
INFO - 2024-10-26 02:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:45:48 --> Model Class Initialized
INFO - 2024-10-26 02:45:48 --> Helper loaded: date_helper
INFO - 2024-10-26 02:45:48 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:45:48 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:45:48 --> Migrations Class Initialized
INFO - 2024-10-26 02:45:48 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:45:48 --> Database Forge Class Initialized
INFO - 2024-10-26 02:45:48 --> Controller Class Initialized
INFO - 2024-10-26 02:45:48 --> Model Class Initialized
INFO - 2024-10-26 02:45:48 --> Model Class Initialized
INFO - 2024-10-26 02:45:48 --> Model Class Initialized
INFO - 2024-10-26 02:45:48 --> Model Class Initialized
INFO - 2024-10-26 03:45:48 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:45:48 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
ERROR - 2024-10-26 03:45:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 108
ERROR - 2024-10-26 03:45:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 138
ERROR - 2024-10-26 03:45:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 545
INFO - 2024-10-26 03:45:48 --> Language file loaded: language/portuguese/profiler_lang.php
INFO - 2024-10-26 03:45:48 --> Profiler Class Initialized
INFO - 2024-10-26 03:45:48 --> Helper loaded: text_helper
INFO - 2024-10-26 03:45:48 --> Final output sent to browser
DEBUG - 2024-10-26 03:45:48 --> Total execution time: 0.0868
INFO - 2024-10-26 02:45:49 --> Config Class Initialized
INFO - 2024-10-26 02:45:49 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:45:49 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:45:49 --> Utf8 Class Initialized
INFO - 2024-10-26 02:45:49 --> URI Class Initialized
INFO - 2024-10-26 02:45:49 --> Router Class Initialized
INFO - 2024-10-26 02:45:49 --> Output Class Initialized
INFO - 2024-10-26 02:45:49 --> Security Class Initialized
DEBUG - 2024-10-26 02:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:45:49 --> Input Class Initialized
INFO - 2024-10-26 02:45:49 --> Language Class Initialized
INFO - 2024-10-26 02:45:49 --> Loader Class Initialized
DEBUG - 2024-10-26 02:45:49 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:45:49 --> Helper loaded: security_helper
INFO - 2024-10-26 02:45:49 --> Helper loaded: form_helper
INFO - 2024-10-26 02:45:49 --> Helper loaded: url_helper
INFO - 2024-10-26 02:45:49 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:45:49 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:45:49 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:45:49 --> Database Driver Class Initialized
INFO - 2024-10-26 02:45:49 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:45:49 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:45:49 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:45:49 --> Email Class Initialized
INFO - 2024-10-26 02:45:49 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:45:49 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:45:49 --> Helper loaded: language_helper
INFO - 2024-10-26 02:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:45:49 --> Model Class Initialized
INFO - 2024-10-26 02:45:49 --> Helper loaded: date_helper
INFO - 2024-10-26 02:45:49 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:45:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:45:49 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:45:49 --> Migrations Class Initialized
INFO - 2024-10-26 02:45:49 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:45:49 --> Database Forge Class Initialized
INFO - 2024-10-26 02:45:49 --> Controller Class Initialized
INFO - 2024-10-26 02:45:49 --> Model Class Initialized
INFO - 2024-10-26 02:45:49 --> Model Class Initialized
INFO - 2024-10-26 02:45:49 --> Model Class Initialized
INFO - 2024-10-26 02:45:49 --> Model Class Initialized
INFO - 2024-10-26 03:45:49 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:45:49 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
ERROR - 2024-10-26 03:45:49 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 108
ERROR - 2024-10-26 03:45:49 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 138
ERROR - 2024-10-26 03:45:49 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 545
INFO - 2024-10-26 03:45:49 --> Language file loaded: language/portuguese/profiler_lang.php
INFO - 2024-10-26 03:45:49 --> Profiler Class Initialized
INFO - 2024-10-26 03:45:49 --> Helper loaded: text_helper
INFO - 2024-10-26 03:45:49 --> Final output sent to browser
DEBUG - 2024-10-26 03:45:49 --> Total execution time: 0.0691
INFO - 2024-10-26 02:45:56 --> Config Class Initialized
INFO - 2024-10-26 02:45:56 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:45:56 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:45:56 --> Utf8 Class Initialized
INFO - 2024-10-26 02:45:56 --> URI Class Initialized
INFO - 2024-10-26 02:45:56 --> Router Class Initialized
INFO - 2024-10-26 02:45:56 --> Output Class Initialized
INFO - 2024-10-26 02:45:56 --> Security Class Initialized
DEBUG - 2024-10-26 02:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:45:56 --> Input Class Initialized
INFO - 2024-10-26 02:45:56 --> Language Class Initialized
INFO - 2024-10-26 02:45:56 --> Loader Class Initialized
DEBUG - 2024-10-26 02:45:56 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:45:56 --> Helper loaded: security_helper
INFO - 2024-10-26 02:45:56 --> Helper loaded: form_helper
INFO - 2024-10-26 02:45:56 --> Helper loaded: url_helper
INFO - 2024-10-26 02:45:56 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:45:56 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:45:56 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:45:56 --> Database Driver Class Initialized
INFO - 2024-10-26 02:45:56 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:45:56 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:45:56 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:45:56 --> Email Class Initialized
INFO - 2024-10-26 02:45:56 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:45:56 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:45:56 --> Helper loaded: language_helper
INFO - 2024-10-26 02:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:45:56 --> Model Class Initialized
INFO - 2024-10-26 02:45:56 --> Helper loaded: date_helper
INFO - 2024-10-26 02:45:56 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:45:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:45:56 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:45:56 --> Migrations Class Initialized
INFO - 2024-10-26 02:45:56 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:45:56 --> Database Forge Class Initialized
INFO - 2024-10-26 02:45:56 --> Controller Class Initialized
INFO - 2024-10-26 02:45:56 --> Model Class Initialized
INFO - 2024-10-26 02:45:56 --> Model Class Initialized
INFO - 2024-10-26 02:45:56 --> Model Class Initialized
INFO - 2024-10-26 02:45:56 --> Model Class Initialized
INFO - 2024-10-26 02:45:59 --> Config Class Initialized
INFO - 2024-10-26 02:45:59 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:45:59 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:45:59 --> Utf8 Class Initialized
INFO - 2024-10-26 02:45:59 --> URI Class Initialized
INFO - 2024-10-26 02:45:59 --> Router Class Initialized
INFO - 2024-10-26 02:45:59 --> Output Class Initialized
INFO - 2024-10-26 02:45:59 --> Security Class Initialized
DEBUG - 2024-10-26 02:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:45:59 --> Input Class Initialized
INFO - 2024-10-26 02:45:59 --> Language Class Initialized
INFO - 2024-10-26 02:45:59 --> Loader Class Initialized
DEBUG - 2024-10-26 02:45:59 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:45:59 --> Helper loaded: security_helper
INFO - 2024-10-26 02:45:59 --> Helper loaded: form_helper
INFO - 2024-10-26 02:45:59 --> Helper loaded: url_helper
INFO - 2024-10-26 02:45:59 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:45:59 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:45:59 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:45:59 --> Database Driver Class Initialized
INFO - 2024-10-26 02:45:59 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:45:59 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:45:59 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:45:59 --> Email Class Initialized
INFO - 2024-10-26 02:45:59 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:45:59 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:45:59 --> Helper loaded: language_helper
INFO - 2024-10-26 02:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:45:59 --> Model Class Initialized
INFO - 2024-10-26 02:45:59 --> Helper loaded: date_helper
INFO - 2024-10-26 02:45:59 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:45:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:45:59 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:45:59 --> Migrations Class Initialized
INFO - 2024-10-26 02:45:59 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:45:59 --> Database Forge Class Initialized
INFO - 2024-10-26 02:45:59 --> Controller Class Initialized
INFO - 2024-10-26 02:45:59 --> Model Class Initialized
INFO - 2024-10-26 02:45:59 --> Model Class Initialized
INFO - 2024-10-26 02:45:59 --> Model Class Initialized
INFO - 2024-10-26 02:45:59 --> Model Class Initialized
INFO - 2024-10-26 03:45:59 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:45:59 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
ERROR - 2024-10-26 03:45:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 108
ERROR - 2024-10-26 03:45:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 138
ERROR - 2024-10-26 03:45:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 545
INFO - 2024-10-26 03:45:59 --> Language file loaded: language/portuguese/profiler_lang.php
INFO - 2024-10-26 03:45:59 --> Profiler Class Initialized
INFO - 2024-10-26 03:45:59 --> Helper loaded: text_helper
INFO - 2024-10-26 03:45:59 --> Final output sent to browser
DEBUG - 2024-10-26 03:45:59 --> Total execution time: 0.0988
INFO - 2024-10-26 02:46:28 --> Config Class Initialized
INFO - 2024-10-26 02:46:28 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:46:28 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:46:28 --> Utf8 Class Initialized
INFO - 2024-10-26 02:46:28 --> URI Class Initialized
INFO - 2024-10-26 02:46:28 --> Router Class Initialized
INFO - 2024-10-26 02:46:28 --> Output Class Initialized
INFO - 2024-10-26 02:46:28 --> Security Class Initialized
DEBUG - 2024-10-26 02:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:46:28 --> Input Class Initialized
INFO - 2024-10-26 02:46:28 --> Language Class Initialized
INFO - 2024-10-26 02:46:28 --> Loader Class Initialized
DEBUG - 2024-10-26 02:46:28 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:46:28 --> Helper loaded: security_helper
INFO - 2024-10-26 02:46:28 --> Helper loaded: form_helper
INFO - 2024-10-26 02:46:28 --> Helper loaded: url_helper
INFO - 2024-10-26 02:46:28 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:46:28 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:46:28 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:46:28 --> Database Driver Class Initialized
INFO - 2024-10-26 02:46:28 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:46:28 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:46:28 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:46:28 --> Email Class Initialized
INFO - 2024-10-26 02:46:28 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:46:28 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:46:28 --> Helper loaded: language_helper
INFO - 2024-10-26 02:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:46:28 --> Model Class Initialized
INFO - 2024-10-26 02:46:28 --> Helper loaded: date_helper
INFO - 2024-10-26 02:46:28 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:46:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:46:28 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:46:28 --> Migrations Class Initialized
INFO - 2024-10-26 02:46:28 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:46:28 --> Database Forge Class Initialized
INFO - 2024-10-26 02:46:28 --> Controller Class Initialized
INFO - 2024-10-26 02:46:28 --> Model Class Initialized
INFO - 2024-10-26 02:46:28 --> Model Class Initialized
INFO - 2024-10-26 02:46:28 --> Model Class Initialized
INFO - 2024-10-26 02:46:28 --> Model Class Initialized
INFO - 2024-10-26 02:48:13 --> Config Class Initialized
INFO - 2024-10-26 02:48:13 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:13 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:13 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:13 --> URI Class Initialized
INFO - 2024-10-26 02:48:13 --> Router Class Initialized
INFO - 2024-10-26 02:48:13 --> Output Class Initialized
INFO - 2024-10-26 02:48:13 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:13 --> Input Class Initialized
INFO - 2024-10-26 02:48:13 --> Language Class Initialized
INFO - 2024-10-26 02:48:13 --> Loader Class Initialized
DEBUG - 2024-10-26 02:48:13 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:48:13 --> Helper loaded: security_helper
INFO - 2024-10-26 02:48:13 --> Helper loaded: form_helper
INFO - 2024-10-26 02:48:13 --> Helper loaded: url_helper
INFO - 2024-10-26 02:48:13 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:48:13 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:48:13 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:48:13 --> Database Driver Class Initialized
INFO - 2024-10-26 02:48:13 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:48:13 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:48:13 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:48:13 --> Email Class Initialized
INFO - 2024-10-26 02:48:13 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:48:13 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:48:13 --> Helper loaded: language_helper
INFO - 2024-10-26 02:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:48:13 --> Model Class Initialized
INFO - 2024-10-26 02:48:13 --> Helper loaded: date_helper
INFO - 2024-10-26 02:48:13 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:48:13 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:48:13 --> Migrations Class Initialized
INFO - 2024-10-26 02:48:13 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:48:13 --> Database Forge Class Initialized
INFO - 2024-10-26 02:48:13 --> Controller Class Initialized
INFO - 2024-10-26 02:48:13 --> Model Class Initialized
INFO - 2024-10-26 02:48:13 --> Model Class Initialized
INFO - 2024-10-26 02:48:13 --> Model Class Initialized
INFO - 2024-10-26 02:48:13 --> Model Class Initialized
INFO - 2024-10-26 02:48:24 --> Config Class Initialized
INFO - 2024-10-26 02:48:24 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:24 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:24 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:24 --> URI Class Initialized
INFO - 2024-10-26 02:48:24 --> Router Class Initialized
INFO - 2024-10-26 02:48:24 --> Output Class Initialized
INFO - 2024-10-26 02:48:24 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:24 --> Input Class Initialized
INFO - 2024-10-26 02:48:24 --> Language Class Initialized
INFO - 2024-10-26 02:48:24 --> Loader Class Initialized
DEBUG - 2024-10-26 02:48:24 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:48:24 --> Helper loaded: security_helper
INFO - 2024-10-26 02:48:24 --> Helper loaded: form_helper
INFO - 2024-10-26 02:48:24 --> Helper loaded: url_helper
INFO - 2024-10-26 02:48:24 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:48:24 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:48:24 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:48:24 --> Database Driver Class Initialized
INFO - 2024-10-26 02:48:24 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:48:24 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:48:24 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:48:24 --> Email Class Initialized
INFO - 2024-10-26 02:48:24 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:48:24 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:48:24 --> Helper loaded: language_helper
INFO - 2024-10-26 02:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:48:24 --> Model Class Initialized
INFO - 2024-10-26 02:48:24 --> Helper loaded: date_helper
INFO - 2024-10-26 02:48:24 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:48:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:48:24 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:48:24 --> Migrations Class Initialized
INFO - 2024-10-26 02:48:24 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:48:24 --> Database Forge Class Initialized
INFO - 2024-10-26 02:48:24 --> Controller Class Initialized
INFO - 2024-10-26 02:48:24 --> Model Class Initialized
INFO - 2024-10-26 02:48:24 --> Model Class Initialized
INFO - 2024-10-26 02:48:24 --> Model Class Initialized
INFO - 2024-10-26 02:48:24 --> Model Class Initialized
INFO - 2024-10-26 02:48:24 --> Config Class Initialized
INFO - 2024-10-26 02:48:24 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:24 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:24 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:24 --> URI Class Initialized
INFO - 2024-10-26 02:48:24 --> Router Class Initialized
INFO - 2024-10-26 02:48:24 --> Output Class Initialized
INFO - 2024-10-26 02:48:24 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:24 --> Input Class Initialized
INFO - 2024-10-26 02:48:24 --> Language Class Initialized
ERROR - 2024-10-26 02:48:24 --> 404 Page Not Found: Credito/lancamento
INFO - 2024-10-26 02:48:32 --> Config Class Initialized
INFO - 2024-10-26 02:48:32 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:32 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:32 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:32 --> URI Class Initialized
INFO - 2024-10-26 02:48:32 --> Router Class Initialized
INFO - 2024-10-26 02:48:32 --> Output Class Initialized
INFO - 2024-10-26 02:48:32 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:32 --> Input Class Initialized
INFO - 2024-10-26 02:48:32 --> Language Class Initialized
INFO - 2024-10-26 02:48:32 --> Loader Class Initialized
DEBUG - 2024-10-26 02:48:32 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:48:32 --> Helper loaded: security_helper
INFO - 2024-10-26 02:48:32 --> Helper loaded: form_helper
INFO - 2024-10-26 02:48:32 --> Helper loaded: url_helper
INFO - 2024-10-26 02:48:32 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:48:32 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:48:32 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:48:32 --> Database Driver Class Initialized
INFO - 2024-10-26 02:48:32 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:48:32 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:48:32 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:48:32 --> Email Class Initialized
INFO - 2024-10-26 02:48:32 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:48:32 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:48:32 --> Helper loaded: language_helper
INFO - 2024-10-26 02:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:48:32 --> Model Class Initialized
INFO - 2024-10-26 02:48:32 --> Helper loaded: date_helper
INFO - 2024-10-26 02:48:32 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:48:32 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:48:32 --> Migrations Class Initialized
INFO - 2024-10-26 02:48:32 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:48:32 --> Database Forge Class Initialized
INFO - 2024-10-26 02:48:32 --> Controller Class Initialized
INFO - 2024-10-26 02:48:32 --> Model Class Initialized
INFO - 2024-10-26 02:48:32 --> Model Class Initialized
INFO - 2024-10-26 02:48:32 --> Model Class Initialized
INFO - 2024-10-26 02:48:32 --> Model Class Initialized
INFO - 2024-10-26 03:48:32 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:48:32 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
ERROR - 2024-10-26 03:48:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 108
ERROR - 2024-10-26 03:48:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 138
ERROR - 2024-10-26 03:48:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 545
INFO - 2024-10-26 03:48:32 --> Language file loaded: language/portuguese/profiler_lang.php
INFO - 2024-10-26 03:48:32 --> Profiler Class Initialized
INFO - 2024-10-26 03:48:32 --> Helper loaded: text_helper
INFO - 2024-10-26 03:48:32 --> Final output sent to browser
DEBUG - 2024-10-26 03:48:32 --> Total execution time: 0.0914
INFO - 2024-10-26 02:48:40 --> Config Class Initialized
INFO - 2024-10-26 02:48:40 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:40 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:40 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:40 --> URI Class Initialized
INFO - 2024-10-26 02:48:40 --> Router Class Initialized
INFO - 2024-10-26 02:48:40 --> Output Class Initialized
INFO - 2024-10-26 02:48:40 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:40 --> Input Class Initialized
INFO - 2024-10-26 02:48:40 --> Language Class Initialized
INFO - 2024-10-26 02:48:40 --> Loader Class Initialized
DEBUG - 2024-10-26 02:48:40 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:48:40 --> Helper loaded: security_helper
INFO - 2024-10-26 02:48:40 --> Helper loaded: form_helper
INFO - 2024-10-26 02:48:40 --> Helper loaded: url_helper
INFO - 2024-10-26 02:48:40 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:48:40 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:48:40 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:48:40 --> Database Driver Class Initialized
INFO - 2024-10-26 02:48:40 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:48:40 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:48:40 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:48:40 --> Email Class Initialized
INFO - 2024-10-26 02:48:40 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:48:40 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:48:40 --> Helper loaded: language_helper
INFO - 2024-10-26 02:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:48:40 --> Model Class Initialized
INFO - 2024-10-26 02:48:40 --> Helper loaded: date_helper
INFO - 2024-10-26 02:48:40 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:48:40 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:48:40 --> Migrations Class Initialized
INFO - 2024-10-26 02:48:40 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:48:40 --> Database Forge Class Initialized
INFO - 2024-10-26 02:48:40 --> Controller Class Initialized
INFO - 2024-10-26 02:48:40 --> Model Class Initialized
INFO - 2024-10-26 02:48:40 --> Model Class Initialized
INFO - 2024-10-26 02:48:40 --> Model Class Initialized
INFO - 2024-10-26 02:48:40 --> Model Class Initialized
INFO - 2024-10-26 02:48:40 --> Config Class Initialized
INFO - 2024-10-26 02:48:40 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:40 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:40 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:40 --> URI Class Initialized
INFO - 2024-10-26 02:48:40 --> Router Class Initialized
INFO - 2024-10-26 02:48:40 --> Output Class Initialized
INFO - 2024-10-26 02:48:40 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:40 --> Input Class Initialized
INFO - 2024-10-26 02:48:40 --> Language Class Initialized
ERROR - 2024-10-26 02:48:40 --> 404 Page Not Found: Credito/lancamento
INFO - 2024-10-26 02:48:50 --> Config Class Initialized
INFO - 2024-10-26 02:48:50 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:50 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:50 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:50 --> URI Class Initialized
INFO - 2024-10-26 02:48:50 --> Router Class Initialized
INFO - 2024-10-26 02:48:50 --> Output Class Initialized
INFO - 2024-10-26 02:48:50 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:50 --> Input Class Initialized
INFO - 2024-10-26 02:48:50 --> Language Class Initialized
INFO - 2024-10-26 02:48:50 --> Loader Class Initialized
DEBUG - 2024-10-26 02:48:50 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:48:50 --> Helper loaded: security_helper
INFO - 2024-10-26 02:48:50 --> Helper loaded: form_helper
INFO - 2024-10-26 02:48:50 --> Helper loaded: url_helper
INFO - 2024-10-26 02:48:50 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:48:50 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:48:50 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:48:50 --> Database Driver Class Initialized
INFO - 2024-10-26 02:48:50 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:48:50 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:48:50 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:48:50 --> Email Class Initialized
INFO - 2024-10-26 02:48:50 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:48:50 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:48:50 --> Helper loaded: language_helper
INFO - 2024-10-26 02:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:48:50 --> Model Class Initialized
INFO - 2024-10-26 02:48:50 --> Helper loaded: date_helper
INFO - 2024-10-26 02:48:50 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:48:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:48:50 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:48:50 --> Migrations Class Initialized
INFO - 2024-10-26 02:48:50 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:48:50 --> Database Forge Class Initialized
INFO - 2024-10-26 02:48:50 --> Controller Class Initialized
INFO - 2024-10-26 02:48:50 --> Model Class Initialized
INFO - 2024-10-26 02:48:50 --> Model Class Initialized
INFO - 2024-10-26 02:48:50 --> Model Class Initialized
INFO - 2024-10-26 02:48:50 --> Model Class Initialized
INFO - 2024-10-26 03:48:50 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:48:50 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
ERROR - 2024-10-26 03:48:50 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 108
ERROR - 2024-10-26 03:48:50 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 138
ERROR - 2024-10-26 03:48:50 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 545
INFO - 2024-10-26 03:48:50 --> Language file loaded: language/portuguese/profiler_lang.php
INFO - 2024-10-26 03:48:50 --> Profiler Class Initialized
INFO - 2024-10-26 03:48:50 --> Helper loaded: text_helper
INFO - 2024-10-26 03:48:50 --> Final output sent to browser
DEBUG - 2024-10-26 03:48:50 --> Total execution time: 0.1275
INFO - 2024-10-26 02:48:57 --> Config Class Initialized
INFO - 2024-10-26 02:48:57 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:57 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:57 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:57 --> URI Class Initialized
INFO - 2024-10-26 02:48:57 --> Router Class Initialized
INFO - 2024-10-26 02:48:57 --> Output Class Initialized
INFO - 2024-10-26 02:48:57 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:57 --> Input Class Initialized
INFO - 2024-10-26 02:48:57 --> Language Class Initialized
INFO - 2024-10-26 02:48:57 --> Loader Class Initialized
DEBUG - 2024-10-26 02:48:57 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:48:57 --> Helper loaded: security_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: form_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: url_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:48:57 --> Database Driver Class Initialized
INFO - 2024-10-26 02:48:57 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:48:57 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:48:57 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:48:57 --> Email Class Initialized
INFO - 2024-10-26 02:48:57 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:48:57 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: language_helper
INFO - 2024-10-26 02:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Helper loaded: date_helper
INFO - 2024-10-26 02:48:57 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:48:57 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:48:57 --> Migrations Class Initialized
INFO - 2024-10-26 02:48:57 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:48:57 --> Database Forge Class Initialized
INFO - 2024-10-26 02:48:57 --> Controller Class Initialized
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Config Class Initialized
INFO - 2024-10-26 02:48:57 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:48:57 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:48:57 --> Utf8 Class Initialized
INFO - 2024-10-26 02:48:57 --> URI Class Initialized
INFO - 2024-10-26 02:48:57 --> Router Class Initialized
INFO - 2024-10-26 02:48:57 --> Output Class Initialized
INFO - 2024-10-26 02:48:57 --> Security Class Initialized
DEBUG - 2024-10-26 02:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:48:57 --> Input Class Initialized
INFO - 2024-10-26 02:48:57 --> Language Class Initialized
INFO - 2024-10-26 02:48:57 --> Loader Class Initialized
DEBUG - 2024-10-26 02:48:57 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:48:57 --> Helper loaded: security_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: form_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: url_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:48:57 --> Database Driver Class Initialized
INFO - 2024-10-26 02:48:57 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:48:57 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:48:57 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:48:57 --> Email Class Initialized
INFO - 2024-10-26 02:48:57 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:48:57 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:48:57 --> Helper loaded: language_helper
INFO - 2024-10-26 02:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Helper loaded: date_helper
INFO - 2024-10-26 02:48:57 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:48:57 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:48:57 --> Migrations Class Initialized
INFO - 2024-10-26 02:48:57 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:48:57 --> Database Forge Class Initialized
INFO - 2024-10-26 02:48:57 --> Controller Class Initialized
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 02:48:57 --> Model Class Initialized
INFO - 2024-10-26 03:48:57 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:48:57 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
ERROR - 2024-10-26 03:48:57 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 108
ERROR - 2024-10-26 03:48:57 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 138
ERROR - 2024-10-26 03:48:57 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /Applications/MAMP/htdocs/credito/system/libraries/Profiler.php 545
INFO - 2024-10-26 03:48:57 --> Language file loaded: language/portuguese/profiler_lang.php
INFO - 2024-10-26 03:48:57 --> Profiler Class Initialized
INFO - 2024-10-26 03:48:57 --> Helper loaded: text_helper
INFO - 2024-10-26 03:48:57 --> Final output sent to browser
DEBUG - 2024-10-26 03:48:57 --> Total execution time: 0.0711
INFO - 2024-10-26 02:49:06 --> Config Class Initialized
INFO - 2024-10-26 02:49:06 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:49:06 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:49:06 --> Utf8 Class Initialized
INFO - 2024-10-26 02:49:06 --> URI Class Initialized
INFO - 2024-10-26 02:49:06 --> Router Class Initialized
INFO - 2024-10-26 02:49:06 --> Output Class Initialized
INFO - 2024-10-26 02:49:06 --> Security Class Initialized
DEBUG - 2024-10-26 02:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:49:06 --> Input Class Initialized
INFO - 2024-10-26 02:49:06 --> Language Class Initialized
INFO - 2024-10-26 02:49:06 --> Loader Class Initialized
DEBUG - 2024-10-26 02:49:06 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:49:06 --> Helper loaded: security_helper
INFO - 2024-10-26 02:49:06 --> Helper loaded: form_helper
INFO - 2024-10-26 02:49:06 --> Helper loaded: url_helper
INFO - 2024-10-26 02:49:06 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:49:06 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:49:06 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:49:06 --> Database Driver Class Initialized
INFO - 2024-10-26 02:49:06 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:49:06 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:49:06 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:49:06 --> Email Class Initialized
INFO - 2024-10-26 02:49:06 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:49:06 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:49:06 --> Helper loaded: language_helper
INFO - 2024-10-26 02:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:49:06 --> Model Class Initialized
INFO - 2024-10-26 02:49:06 --> Helper loaded: date_helper
INFO - 2024-10-26 02:49:06 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:49:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:49:06 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:49:06 --> Migrations Class Initialized
INFO - 2024-10-26 02:49:06 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:49:06 --> Database Forge Class Initialized
INFO - 2024-10-26 02:49:06 --> Controller Class Initialized
INFO - 2024-10-26 02:49:06 --> Model Class Initialized
INFO - 2024-10-26 02:49:06 --> Model Class Initialized
INFO - 2024-10-26 02:49:06 --> Model Class Initialized
INFO - 2024-10-26 02:49:06 --> Model Class Initialized
INFO - 2024-10-26 03:49:06 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:49:06 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 03:49:06 --> Final output sent to browser
DEBUG - 2024-10-26 03:49:06 --> Total execution time: 0.0731
INFO - 2024-10-26 02:49:10 --> Config Class Initialized
INFO - 2024-10-26 02:49:10 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:49:10 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:49:10 --> Utf8 Class Initialized
INFO - 2024-10-26 02:49:10 --> URI Class Initialized
INFO - 2024-10-26 02:49:10 --> Router Class Initialized
INFO - 2024-10-26 02:49:10 --> Output Class Initialized
INFO - 2024-10-26 02:49:10 --> Security Class Initialized
DEBUG - 2024-10-26 02:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:49:10 --> Input Class Initialized
INFO - 2024-10-26 02:49:10 --> Language Class Initialized
INFO - 2024-10-26 02:49:10 --> Loader Class Initialized
DEBUG - 2024-10-26 02:49:10 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:49:10 --> Helper loaded: security_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: form_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: url_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:49:10 --> Database Driver Class Initialized
INFO - 2024-10-26 02:49:10 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:49:10 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:49:10 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:49:10 --> Email Class Initialized
INFO - 2024-10-26 02:49:10 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:49:10 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: language_helper
INFO - 2024-10-26 02:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Helper loaded: date_helper
INFO - 2024-10-26 02:49:10 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:49:10 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:49:10 --> Migrations Class Initialized
INFO - 2024-10-26 02:49:10 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:49:10 --> Database Forge Class Initialized
INFO - 2024-10-26 02:49:10 --> Controller Class Initialized
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Config Class Initialized
INFO - 2024-10-26 02:49:10 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:49:10 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:49:10 --> Utf8 Class Initialized
INFO - 2024-10-26 02:49:10 --> URI Class Initialized
INFO - 2024-10-26 02:49:10 --> Router Class Initialized
INFO - 2024-10-26 02:49:10 --> Output Class Initialized
INFO - 2024-10-26 02:49:10 --> Security Class Initialized
DEBUG - 2024-10-26 02:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:49:10 --> Input Class Initialized
INFO - 2024-10-26 02:49:10 --> Language Class Initialized
INFO - 2024-10-26 02:49:10 --> Loader Class Initialized
DEBUG - 2024-10-26 02:49:10 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:49:10 --> Helper loaded: security_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: form_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: url_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:49:10 --> Database Driver Class Initialized
INFO - 2024-10-26 02:49:10 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:49:10 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:49:10 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:49:10 --> Email Class Initialized
INFO - 2024-10-26 02:49:10 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:49:10 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:49:10 --> Helper loaded: language_helper
INFO - 2024-10-26 02:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Helper loaded: date_helper
INFO - 2024-10-26 02:49:10 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:49:10 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:49:10 --> Migrations Class Initialized
INFO - 2024-10-26 02:49:10 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:49:10 --> Database Forge Class Initialized
INFO - 2024-10-26 02:49:10 --> Controller Class Initialized
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 02:49:10 --> Model Class Initialized
INFO - 2024-10-26 03:49:10 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/lancamento/index.php
INFO - 2024-10-26 03:49:10 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 03:49:10 --> Final output sent to browser
DEBUG - 2024-10-26 03:49:10 --> Total execution time: 0.0791
INFO - 2024-10-26 02:49:16 --> Config Class Initialized
INFO - 2024-10-26 02:49:16 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:49:16 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:49:16 --> Utf8 Class Initialized
INFO - 2024-10-26 02:49:16 --> URI Class Initialized
DEBUG - 2024-10-26 02:49:16 --> No URI present. Default controller set.
INFO - 2024-10-26 02:49:16 --> Router Class Initialized
INFO - 2024-10-26 02:49:16 --> Output Class Initialized
INFO - 2024-10-26 02:49:16 --> Security Class Initialized
DEBUG - 2024-10-26 02:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:49:16 --> Input Class Initialized
INFO - 2024-10-26 02:49:16 --> Language Class Initialized
INFO - 2024-10-26 02:49:16 --> Loader Class Initialized
DEBUG - 2024-10-26 02:49:16 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:49:16 --> Helper loaded: security_helper
INFO - 2024-10-26 02:49:16 --> Helper loaded: form_helper
INFO - 2024-10-26 02:49:16 --> Helper loaded: url_helper
INFO - 2024-10-26 02:49:16 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:49:16 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:49:16 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:49:16 --> Database Driver Class Initialized
INFO - 2024-10-26 02:49:16 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:49:16 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:49:16 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:49:16 --> Email Class Initialized
INFO - 2024-10-26 02:49:16 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:49:16 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:49:16 --> Helper loaded: language_helper
INFO - 2024-10-26 02:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:49:16 --> Model Class Initialized
INFO - 2024-10-26 02:49:16 --> Helper loaded: date_helper
INFO - 2024-10-26 02:49:16 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:49:16 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:49:16 --> Migrations Class Initialized
INFO - 2024-10-26 02:49:16 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:49:16 --> Database Forge Class Initialized
INFO - 2024-10-26 02:49:16 --> Controller Class Initialized
INFO - 2024-10-26 02:49:16 --> Model Class Initialized
INFO - 2024-10-26 02:49:16 --> Model Class Initialized
INFO - 2024-10-26 02:49:16 --> Model Class Initialized
INFO - 2024-10-26 02:49:16 --> Model Class Initialized
INFO - 2024-10-26 03:49:16 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 03:49:16 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 03:49:16 --> Final output sent to browser
DEBUG - 2024-10-26 03:49:16 --> Total execution time: 0.0723
INFO - 2024-10-26 02:56:01 --> Config Class Initialized
INFO - 2024-10-26 02:56:01 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:56:01 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:56:01 --> Utf8 Class Initialized
INFO - 2024-10-26 02:56:01 --> URI Class Initialized
INFO - 2024-10-26 02:56:01 --> Router Class Initialized
INFO - 2024-10-26 02:56:01 --> Output Class Initialized
INFO - 2024-10-26 02:56:01 --> Security Class Initialized
DEBUG - 2024-10-26 02:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:56:01 --> Input Class Initialized
INFO - 2024-10-26 02:56:01 --> Language Class Initialized
INFO - 2024-10-26 02:56:01 --> Loader Class Initialized
DEBUG - 2024-10-26 02:56:01 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:56:01 --> Helper loaded: security_helper
INFO - 2024-10-26 02:56:01 --> Helper loaded: form_helper
INFO - 2024-10-26 02:56:01 --> Helper loaded: url_helper
INFO - 2024-10-26 02:56:01 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:56:01 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:56:01 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:56:01 --> Database Driver Class Initialized
INFO - 2024-10-26 02:56:01 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:56:01 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:56:01 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:56:01 --> Email Class Initialized
INFO - 2024-10-26 02:56:01 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:56:01 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:56:01 --> Helper loaded: language_helper
INFO - 2024-10-26 02:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:56:01 --> Model Class Initialized
INFO - 2024-10-26 02:56:01 --> Helper loaded: date_helper
INFO - 2024-10-26 02:56:01 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:56:01 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:56:01 --> Migrations Class Initialized
INFO - 2024-10-26 02:56:01 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:56:01 --> Database Forge Class Initialized
INFO - 2024-10-26 02:56:01 --> Controller Class Initialized
INFO - 2024-10-26 02:56:01 --> Model Class Initialized
INFO - 2024-10-26 02:56:01 --> Model Class Initialized
INFO - 2024-10-26 02:56:01 --> Model Class Initialized
DEBUG - 2024-10-26 02:56:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:56:01 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/instituicoes/index.php
INFO - 2024-10-26 03:56:01 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 03:56:01 --> Final output sent to browser
DEBUG - 2024-10-26 03:56:01 --> Total execution time: 0.0857
INFO - 2024-10-26 02:56:02 --> Config Class Initialized
INFO - 2024-10-26 02:56:02 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:56:02 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:56:02 --> Utf8 Class Initialized
INFO - 2024-10-26 02:56:02 --> URI Class Initialized
DEBUG - 2024-10-26 02:56:02 --> No URI present. Default controller set.
INFO - 2024-10-26 02:56:02 --> Router Class Initialized
INFO - 2024-10-26 02:56:02 --> Output Class Initialized
INFO - 2024-10-26 02:56:02 --> Security Class Initialized
DEBUG - 2024-10-26 02:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:56:02 --> Input Class Initialized
INFO - 2024-10-26 02:56:02 --> Language Class Initialized
INFO - 2024-10-26 02:56:02 --> Loader Class Initialized
DEBUG - 2024-10-26 02:56:02 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 02:56:02 --> Helper loaded: security_helper
INFO - 2024-10-26 02:56:02 --> Helper loaded: form_helper
INFO - 2024-10-26 02:56:02 --> Helper loaded: url_helper
INFO - 2024-10-26 02:56:02 --> Helper loaded: datetime_helper
INFO - 2024-10-26 02:56:02 --> Helper loaded: numbers_helper
INFO - 2024-10-26 02:56:02 --> Helper loaded: strings_helper
INFO - 2024-10-26 02:56:02 --> Database Driver Class Initialized
INFO - 2024-10-26 02:56:02 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 02:56:02 --> Pagination Class Initialized
DEBUG - 2024-10-26 02:56:02 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 02:56:02 --> Email Class Initialized
INFO - 2024-10-26 02:56:02 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 02:56:02 --> Helper loaded: cookie_helper
INFO - 2024-10-26 02:56:02 --> Helper loaded: language_helper
INFO - 2024-10-26 02:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 02:56:02 --> Model Class Initialized
INFO - 2024-10-26 02:56:02 --> Helper loaded: date_helper
INFO - 2024-10-26 02:56:02 --> Form Validation Class Initialized
DEBUG - 2024-10-26 02:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 02:56:02 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 02:56:02 --> Migrations Class Initialized
INFO - 2024-10-26 02:56:02 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 02:56:02 --> Database Forge Class Initialized
INFO - 2024-10-26 02:56:02 --> Controller Class Initialized
INFO - 2024-10-26 02:56:02 --> Model Class Initialized
INFO - 2024-10-26 02:56:02 --> Model Class Initialized
INFO - 2024-10-26 02:56:02 --> Model Class Initialized
INFO - 2024-10-26 02:56:02 --> Model Class Initialized
INFO - 2024-10-26 03:56:02 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 03:56:02 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 03:56:02 --> Final output sent to browser
DEBUG - 2024-10-26 03:56:02 --> Total execution time: 0.0726
INFO - 2024-10-26 03:25:16 --> Config Class Initialized
INFO - 2024-10-26 03:25:16 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:25:16 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:25:16 --> Utf8 Class Initialized
INFO - 2024-10-26 03:25:16 --> URI Class Initialized
DEBUG - 2024-10-26 03:25:16 --> No URI present. Default controller set.
INFO - 2024-10-26 03:25:16 --> Router Class Initialized
INFO - 2024-10-26 03:25:16 --> Output Class Initialized
INFO - 2024-10-26 03:25:16 --> Security Class Initialized
DEBUG - 2024-10-26 03:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:25:16 --> Input Class Initialized
INFO - 2024-10-26 03:25:16 --> Language Class Initialized
INFO - 2024-10-26 03:25:16 --> Loader Class Initialized
DEBUG - 2024-10-26 03:25:16 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 03:25:16 --> Helper loaded: security_helper
INFO - 2024-10-26 03:25:16 --> Helper loaded: form_helper
INFO - 2024-10-26 03:25:16 --> Helper loaded: url_helper
INFO - 2024-10-26 03:25:16 --> Helper loaded: datetime_helper
INFO - 2024-10-26 03:25:16 --> Helper loaded: numbers_helper
INFO - 2024-10-26 03:25:16 --> Helper loaded: strings_helper
INFO - 2024-10-26 03:25:16 --> Database Driver Class Initialized
INFO - 2024-10-26 03:25:16 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 03:25:16 --> Pagination Class Initialized
DEBUG - 2024-10-26 03:25:16 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 03:25:16 --> Email Class Initialized
INFO - 2024-10-26 03:25:16 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 03:25:16 --> Helper loaded: cookie_helper
INFO - 2024-10-26 03:25:16 --> Helper loaded: language_helper
INFO - 2024-10-26 03:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:25:16 --> Model Class Initialized
INFO - 2024-10-26 03:25:16 --> Helper loaded: date_helper
INFO - 2024-10-26 03:25:16 --> Form Validation Class Initialized
DEBUG - 2024-10-26 03:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 03:25:16 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:25:16 --> Migrations Class Initialized
INFO - 2024-10-26 03:25:16 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 03:25:16 --> Database Forge Class Initialized
INFO - 2024-10-26 03:25:16 --> Controller Class Initialized
INFO - 2024-10-26 03:25:16 --> Model Class Initialized
INFO - 2024-10-26 03:25:16 --> Model Class Initialized
INFO - 2024-10-26 03:25:16 --> Model Class Initialized
INFO - 2024-10-26 03:25:16 --> Model Class Initialized
INFO - 2024-10-26 04:25:16 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 04:25:16 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 04:25:16 --> Final output sent to browser
DEBUG - 2024-10-26 04:25:16 --> Total execution time: 0.1426
INFO - 2024-10-26 03:25:25 --> Config Class Initialized
INFO - 2024-10-26 03:25:25 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:25:25 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:25:25 --> Utf8 Class Initialized
INFO - 2024-10-26 03:25:25 --> URI Class Initialized
INFO - 2024-10-26 03:25:25 --> Router Class Initialized
INFO - 2024-10-26 03:25:25 --> Output Class Initialized
INFO - 2024-10-26 03:25:25 --> Security Class Initialized
DEBUG - 2024-10-26 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:25:25 --> Input Class Initialized
INFO - 2024-10-26 03:25:25 --> Language Class Initialized
ERROR - 2024-10-26 03:25:25 --> 404 Page Not Found: Resources/css
INFO - 2024-10-26 03:26:00 --> Config Class Initialized
INFO - 2024-10-26 03:26:00 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:26:00 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:26:00 --> Utf8 Class Initialized
INFO - 2024-10-26 03:26:00 --> URI Class Initialized
DEBUG - 2024-10-26 03:26:00 --> No URI present. Default controller set.
INFO - 2024-10-26 03:26:00 --> Router Class Initialized
INFO - 2024-10-26 03:26:00 --> Output Class Initialized
INFO - 2024-10-26 03:26:00 --> Security Class Initialized
DEBUG - 2024-10-26 03:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:26:00 --> Input Class Initialized
INFO - 2024-10-26 03:26:00 --> Language Class Initialized
INFO - 2024-10-26 03:26:00 --> Loader Class Initialized
DEBUG - 2024-10-26 03:26:00 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 03:26:00 --> Helper loaded: security_helper
INFO - 2024-10-26 03:26:00 --> Helper loaded: form_helper
INFO - 2024-10-26 03:26:00 --> Helper loaded: url_helper
INFO - 2024-10-26 03:26:00 --> Helper loaded: datetime_helper
INFO - 2024-10-26 03:26:00 --> Helper loaded: numbers_helper
INFO - 2024-10-26 03:26:00 --> Helper loaded: strings_helper
INFO - 2024-10-26 03:26:00 --> Database Driver Class Initialized
INFO - 2024-10-26 03:26:00 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 03:26:00 --> Pagination Class Initialized
DEBUG - 2024-10-26 03:26:00 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 03:26:00 --> Email Class Initialized
INFO - 2024-10-26 03:26:00 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 03:26:00 --> Helper loaded: cookie_helper
INFO - 2024-10-26 03:26:00 --> Helper loaded: language_helper
INFO - 2024-10-26 03:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:26:00 --> Model Class Initialized
INFO - 2024-10-26 03:26:00 --> Helper loaded: date_helper
INFO - 2024-10-26 03:26:00 --> Form Validation Class Initialized
DEBUG - 2024-10-26 03:26:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 03:26:00 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:26:00 --> Migrations Class Initialized
INFO - 2024-10-26 03:26:00 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 03:26:00 --> Database Forge Class Initialized
INFO - 2024-10-26 03:26:00 --> Controller Class Initialized
INFO - 2024-10-26 03:26:00 --> Model Class Initialized
INFO - 2024-10-26 03:26:00 --> Model Class Initialized
INFO - 2024-10-26 03:26:00 --> Model Class Initialized
INFO - 2024-10-26 03:26:00 --> Model Class Initialized
INFO - 2024-10-26 04:26:00 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 04:26:00 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 04:26:00 --> Final output sent to browser
DEBUG - 2024-10-26 04:26:00 --> Total execution time: 0.0991
INFO - 2024-10-26 03:29:30 --> Config Class Initialized
INFO - 2024-10-26 03:29:30 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:29:30 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:29:30 --> Utf8 Class Initialized
INFO - 2024-10-26 03:29:30 --> URI Class Initialized
DEBUG - 2024-10-26 03:29:30 --> No URI present. Default controller set.
INFO - 2024-10-26 03:29:30 --> Router Class Initialized
INFO - 2024-10-26 03:29:30 --> Output Class Initialized
INFO - 2024-10-26 03:29:30 --> Security Class Initialized
DEBUG - 2024-10-26 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:29:30 --> Input Class Initialized
INFO - 2024-10-26 03:29:30 --> Language Class Initialized
INFO - 2024-10-26 03:29:30 --> Loader Class Initialized
DEBUG - 2024-10-26 03:29:30 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 03:29:30 --> Helper loaded: security_helper
INFO - 2024-10-26 03:29:30 --> Helper loaded: form_helper
INFO - 2024-10-26 03:29:30 --> Helper loaded: url_helper
INFO - 2024-10-26 03:29:30 --> Helper loaded: datetime_helper
INFO - 2024-10-26 03:29:30 --> Helper loaded: numbers_helper
INFO - 2024-10-26 03:29:30 --> Helper loaded: strings_helper
INFO - 2024-10-26 03:29:30 --> Database Driver Class Initialized
INFO - 2024-10-26 03:29:30 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 03:29:30 --> Pagination Class Initialized
DEBUG - 2024-10-26 03:29:30 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 03:29:30 --> Email Class Initialized
INFO - 2024-10-26 03:29:30 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 03:29:30 --> Helper loaded: cookie_helper
INFO - 2024-10-26 03:29:30 --> Helper loaded: language_helper
INFO - 2024-10-26 03:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:29:30 --> Model Class Initialized
INFO - 2024-10-26 03:29:30 --> Helper loaded: date_helper
INFO - 2024-10-26 03:29:30 --> Form Validation Class Initialized
DEBUG - 2024-10-26 03:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 03:29:30 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:29:30 --> Migrations Class Initialized
INFO - 2024-10-26 03:29:30 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 03:29:30 --> Database Forge Class Initialized
INFO - 2024-10-26 03:29:30 --> Controller Class Initialized
INFO - 2024-10-26 03:29:30 --> Model Class Initialized
INFO - 2024-10-26 03:29:31 --> Model Class Initialized
INFO - 2024-10-26 03:29:31 --> Model Class Initialized
INFO - 2024-10-26 03:29:31 --> Model Class Initialized
ERROR - 2024-10-26 04:29:31 --> Severity: Notice --> Undefined variable: data_demandas_sem_sucesso /Applications/MAMP/htdocs/credito/application/views/dashboard.php 179
ERROR - 2024-10-26 04:29:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/credito/application/views/dashboard.php 179
INFO - 2024-10-26 04:29:31 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 04:29:31 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 04:29:31 --> Final output sent to browser
DEBUG - 2024-10-26 04:29:31 --> Total execution time: 0.1002
INFO - 2024-10-26 03:35:20 --> Config Class Initialized
INFO - 2024-10-26 03:35:20 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:35:20 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:35:20 --> Utf8 Class Initialized
INFO - 2024-10-26 03:35:20 --> URI Class Initialized
DEBUG - 2024-10-26 03:35:20 --> No URI present. Default controller set.
INFO - 2024-10-26 03:35:20 --> Router Class Initialized
INFO - 2024-10-26 03:35:20 --> Output Class Initialized
INFO - 2024-10-26 03:35:20 --> Security Class Initialized
DEBUG - 2024-10-26 03:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:35:20 --> Input Class Initialized
INFO - 2024-10-26 03:35:20 --> Language Class Initialized
INFO - 2024-10-26 03:35:20 --> Loader Class Initialized
DEBUG - 2024-10-26 03:35:20 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 03:35:20 --> Helper loaded: security_helper
INFO - 2024-10-26 03:35:20 --> Helper loaded: form_helper
INFO - 2024-10-26 03:35:20 --> Helper loaded: url_helper
INFO - 2024-10-26 03:35:20 --> Helper loaded: datetime_helper
INFO - 2024-10-26 03:35:20 --> Helper loaded: numbers_helper
INFO - 2024-10-26 03:35:20 --> Helper loaded: strings_helper
INFO - 2024-10-26 03:35:20 --> Database Driver Class Initialized
INFO - 2024-10-26 03:35:20 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 03:35:20 --> Pagination Class Initialized
DEBUG - 2024-10-26 03:35:20 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 03:35:20 --> Email Class Initialized
INFO - 2024-10-26 03:35:20 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 03:35:20 --> Helper loaded: cookie_helper
INFO - 2024-10-26 03:35:20 --> Helper loaded: language_helper
INFO - 2024-10-26 03:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:35:20 --> Model Class Initialized
INFO - 2024-10-26 03:35:20 --> Helper loaded: date_helper
INFO - 2024-10-26 03:35:20 --> Form Validation Class Initialized
DEBUG - 2024-10-26 03:35:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 03:35:20 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:35:20 --> Migrations Class Initialized
INFO - 2024-10-26 03:35:20 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 03:35:20 --> Database Forge Class Initialized
INFO - 2024-10-26 03:35:20 --> Controller Class Initialized
INFO - 2024-10-26 03:35:20 --> Model Class Initialized
INFO - 2024-10-26 03:35:20 --> Model Class Initialized
INFO - 2024-10-26 03:35:20 --> Model Class Initialized
INFO - 2024-10-26 03:35:20 --> Model Class Initialized
ERROR - 2024-10-26 04:35:20 --> Severity: Notice --> Undefined variable: data_demandas_sem_sucesso /Applications/MAMP/htdocs/credito/application/views/dashboard.php 180
ERROR - 2024-10-26 04:35:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/credito/application/views/dashboard.php 180
INFO - 2024-10-26 04:35:20 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 04:35:20 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 04:35:20 --> Final output sent to browser
DEBUG - 2024-10-26 04:35:20 --> Total execution time: 0.0880
INFO - 2024-10-26 03:35:27 --> Config Class Initialized
INFO - 2024-10-26 03:35:27 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:35:27 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:35:27 --> Utf8 Class Initialized
INFO - 2024-10-26 03:35:27 --> URI Class Initialized
DEBUG - 2024-10-26 03:35:27 --> No URI present. Default controller set.
INFO - 2024-10-26 03:35:27 --> Router Class Initialized
INFO - 2024-10-26 03:35:27 --> Output Class Initialized
INFO - 2024-10-26 03:35:27 --> Security Class Initialized
DEBUG - 2024-10-26 03:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:35:27 --> Input Class Initialized
INFO - 2024-10-26 03:35:27 --> Language Class Initialized
INFO - 2024-10-26 03:35:27 --> Loader Class Initialized
DEBUG - 2024-10-26 03:35:27 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 03:35:27 --> Helper loaded: security_helper
INFO - 2024-10-26 03:35:27 --> Helper loaded: form_helper
INFO - 2024-10-26 03:35:27 --> Helper loaded: url_helper
INFO - 2024-10-26 03:35:27 --> Helper loaded: datetime_helper
INFO - 2024-10-26 03:35:27 --> Helper loaded: numbers_helper
INFO - 2024-10-26 03:35:27 --> Helper loaded: strings_helper
INFO - 2024-10-26 03:35:27 --> Database Driver Class Initialized
INFO - 2024-10-26 03:35:27 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 03:35:27 --> Pagination Class Initialized
DEBUG - 2024-10-26 03:35:27 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 03:35:27 --> Email Class Initialized
INFO - 2024-10-26 03:35:27 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 03:35:27 --> Helper loaded: cookie_helper
INFO - 2024-10-26 03:35:27 --> Helper loaded: language_helper
INFO - 2024-10-26 03:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:35:27 --> Model Class Initialized
INFO - 2024-10-26 03:35:27 --> Helper loaded: date_helper
INFO - 2024-10-26 03:35:27 --> Form Validation Class Initialized
DEBUG - 2024-10-26 03:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 03:35:27 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:35:27 --> Migrations Class Initialized
INFO - 2024-10-26 03:35:27 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 03:35:27 --> Database Forge Class Initialized
INFO - 2024-10-26 03:35:27 --> Controller Class Initialized
INFO - 2024-10-26 03:35:27 --> Model Class Initialized
INFO - 2024-10-26 03:35:27 --> Model Class Initialized
INFO - 2024-10-26 03:35:27 --> Model Class Initialized
INFO - 2024-10-26 03:35:27 --> Model Class Initialized
INFO - 2024-10-26 04:35:27 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 04:35:27 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 04:35:27 --> Final output sent to browser
DEBUG - 2024-10-26 04:35:27 --> Total execution time: 0.1172
INFO - 2024-10-26 03:36:47 --> Config Class Initialized
INFO - 2024-10-26 03:36:47 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:36:47 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:36:47 --> Utf8 Class Initialized
INFO - 2024-10-26 03:36:47 --> URI Class Initialized
DEBUG - 2024-10-26 03:36:47 --> No URI present. Default controller set.
INFO - 2024-10-26 03:36:47 --> Router Class Initialized
INFO - 2024-10-26 03:36:47 --> Output Class Initialized
INFO - 2024-10-26 03:36:47 --> Security Class Initialized
DEBUG - 2024-10-26 03:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:36:47 --> Input Class Initialized
INFO - 2024-10-26 03:36:47 --> Language Class Initialized
INFO - 2024-10-26 03:36:47 --> Loader Class Initialized
DEBUG - 2024-10-26 03:36:47 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 03:36:47 --> Helper loaded: security_helper
INFO - 2024-10-26 03:36:47 --> Helper loaded: form_helper
INFO - 2024-10-26 03:36:47 --> Helper loaded: url_helper
INFO - 2024-10-26 03:36:47 --> Helper loaded: datetime_helper
INFO - 2024-10-26 03:36:47 --> Helper loaded: numbers_helper
INFO - 2024-10-26 03:36:47 --> Helper loaded: strings_helper
INFO - 2024-10-26 03:36:47 --> Database Driver Class Initialized
INFO - 2024-10-26 03:36:47 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 03:36:47 --> Pagination Class Initialized
DEBUG - 2024-10-26 03:36:47 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 03:36:47 --> Email Class Initialized
INFO - 2024-10-26 03:36:47 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 03:36:47 --> Helper loaded: cookie_helper
INFO - 2024-10-26 03:36:47 --> Helper loaded: language_helper
INFO - 2024-10-26 03:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:36:47 --> Model Class Initialized
INFO - 2024-10-26 03:36:47 --> Helper loaded: date_helper
INFO - 2024-10-26 03:36:47 --> Form Validation Class Initialized
DEBUG - 2024-10-26 03:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 03:36:47 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:36:47 --> Migrations Class Initialized
INFO - 2024-10-26 03:36:47 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 03:36:47 --> Database Forge Class Initialized
INFO - 2024-10-26 03:36:47 --> Controller Class Initialized
INFO - 2024-10-26 03:36:47 --> Model Class Initialized
INFO - 2024-10-26 03:36:47 --> Model Class Initialized
INFO - 2024-10-26 03:36:47 --> Model Class Initialized
INFO - 2024-10-26 03:36:47 --> Model Class Initialized
ERROR - 2024-10-26 04:36:47 --> Severity: Notice --> Undefined variable: data_demandas_sem_sucesso /Applications/MAMP/htdocs/credito/application/views/dashboard.php 201
ERROR - 2024-10-26 04:36:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/credito/application/views/dashboard.php 201
INFO - 2024-10-26 04:36:47 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 04:36:47 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 04:36:47 --> Final output sent to browser
DEBUG - 2024-10-26 04:36:47 --> Total execution time: 0.0933
INFO - 2024-10-26 03:36:52 --> Config Class Initialized
INFO - 2024-10-26 03:36:52 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:36:52 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:36:52 --> Utf8 Class Initialized
INFO - 2024-10-26 03:36:52 --> URI Class Initialized
INFO - 2024-10-26 03:36:52 --> Router Class Initialized
INFO - 2024-10-26 03:36:52 --> Output Class Initialized
INFO - 2024-10-26 03:36:52 --> Security Class Initialized
DEBUG - 2024-10-26 03:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:36:52 --> Input Class Initialized
INFO - 2024-10-26 03:36:52 --> Language Class Initialized
ERROR - 2024-10-26 03:36:52 --> 404 Page Not Found: Resources/css
INFO - 2024-10-26 03:37:06 --> Config Class Initialized
INFO - 2024-10-26 03:37:06 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:37:06 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:37:06 --> Utf8 Class Initialized
INFO - 2024-10-26 03:37:06 --> URI Class Initialized
DEBUG - 2024-10-26 03:37:06 --> No URI present. Default controller set.
INFO - 2024-10-26 03:37:06 --> Router Class Initialized
INFO - 2024-10-26 03:37:06 --> Output Class Initialized
INFO - 2024-10-26 03:37:06 --> Security Class Initialized
DEBUG - 2024-10-26 03:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:37:06 --> Input Class Initialized
INFO - 2024-10-26 03:37:06 --> Language Class Initialized
INFO - 2024-10-26 03:37:06 --> Loader Class Initialized
DEBUG - 2024-10-26 03:37:06 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 03:37:06 --> Helper loaded: security_helper
INFO - 2024-10-26 03:37:06 --> Helper loaded: form_helper
INFO - 2024-10-26 03:37:06 --> Helper loaded: url_helper
INFO - 2024-10-26 03:37:06 --> Helper loaded: datetime_helper
INFO - 2024-10-26 03:37:06 --> Helper loaded: numbers_helper
INFO - 2024-10-26 03:37:06 --> Helper loaded: strings_helper
INFO - 2024-10-26 03:37:06 --> Database Driver Class Initialized
INFO - 2024-10-26 03:37:06 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 03:37:06 --> Pagination Class Initialized
DEBUG - 2024-10-26 03:37:06 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 03:37:06 --> Email Class Initialized
INFO - 2024-10-26 03:37:06 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 03:37:06 --> Helper loaded: cookie_helper
INFO - 2024-10-26 03:37:06 --> Helper loaded: language_helper
INFO - 2024-10-26 03:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:37:06 --> Model Class Initialized
INFO - 2024-10-26 03:37:06 --> Helper loaded: date_helper
INFO - 2024-10-26 03:37:06 --> Form Validation Class Initialized
DEBUG - 2024-10-26 03:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 03:37:06 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:37:06 --> Migrations Class Initialized
INFO - 2024-10-26 03:37:06 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 03:37:06 --> Database Forge Class Initialized
INFO - 2024-10-26 03:37:06 --> Controller Class Initialized
INFO - 2024-10-26 03:37:06 --> Model Class Initialized
INFO - 2024-10-26 03:37:06 --> Model Class Initialized
INFO - 2024-10-26 03:37:06 --> Model Class Initialized
INFO - 2024-10-26 03:37:06 --> Model Class Initialized
ERROR - 2024-10-26 04:37:06 --> Severity: Notice --> Undefined variable: data_demandas_sem_sucesso /Applications/MAMP/htdocs/credito/application/views/dashboard.php 201
ERROR - 2024-10-26 04:37:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/credito/application/views/dashboard.php 201
INFO - 2024-10-26 04:37:06 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 04:37:06 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 04:37:06 --> Final output sent to browser
DEBUG - 2024-10-26 04:37:06 --> Total execution time: 0.0862
INFO - 2024-10-26 03:46:46 --> Config Class Initialized
INFO - 2024-10-26 03:46:46 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:46:46 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:46:46 --> Utf8 Class Initialized
INFO - 2024-10-26 03:46:46 --> URI Class Initialized
DEBUG - 2024-10-26 03:46:46 --> No URI present. Default controller set.
INFO - 2024-10-26 03:46:46 --> Router Class Initialized
INFO - 2024-10-26 03:46:46 --> Output Class Initialized
INFO - 2024-10-26 03:46:46 --> Security Class Initialized
DEBUG - 2024-10-26 03:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:46:46 --> Input Class Initialized
INFO - 2024-10-26 03:46:46 --> Language Class Initialized
INFO - 2024-10-26 03:46:46 --> Loader Class Initialized
DEBUG - 2024-10-26 03:46:46 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 03:46:46 --> Helper loaded: security_helper
INFO - 2024-10-26 03:46:46 --> Helper loaded: form_helper
INFO - 2024-10-26 03:46:46 --> Helper loaded: url_helper
INFO - 2024-10-26 03:46:46 --> Helper loaded: datetime_helper
INFO - 2024-10-26 03:46:46 --> Helper loaded: numbers_helper
INFO - 2024-10-26 03:46:46 --> Helper loaded: strings_helper
INFO - 2024-10-26 03:46:46 --> Database Driver Class Initialized
INFO - 2024-10-26 03:46:46 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 03:46:46 --> Pagination Class Initialized
DEBUG - 2024-10-26 03:46:46 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 03:46:46 --> Email Class Initialized
INFO - 2024-10-26 03:46:46 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 03:46:46 --> Helper loaded: cookie_helper
INFO - 2024-10-26 03:46:46 --> Helper loaded: language_helper
INFO - 2024-10-26 03:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:46:46 --> Model Class Initialized
INFO - 2024-10-26 03:46:46 --> Helper loaded: date_helper
INFO - 2024-10-26 03:46:46 --> Form Validation Class Initialized
DEBUG - 2024-10-26 03:46:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 03:46:46 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 03:46:46 --> Migrations Class Initialized
INFO - 2024-10-26 03:46:46 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 03:46:46 --> Database Forge Class Initialized
INFO - 2024-10-26 03:46:46 --> Controller Class Initialized
INFO - 2024-10-26 03:46:46 --> Model Class Initialized
INFO - 2024-10-26 03:46:46 --> Model Class Initialized
INFO - 2024-10-26 03:46:46 --> Model Class Initialized
INFO - 2024-10-26 03:46:46 --> Model Class Initialized
ERROR - 2024-10-26 03:46:46 --> Severity: error --> Exception: Call to undefined method Demandas_model::get_demandas_encerradas_com_sucesso_por_mes() /Applications/MAMP/htdocs/credito/application/controllers/Dashboard.php 29
INFO - 2024-10-26 04:25:31 --> Config Class Initialized
INFO - 2024-10-26 04:25:31 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:25:31 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:25:31 --> Utf8 Class Initialized
INFO - 2024-10-26 04:25:31 --> URI Class Initialized
DEBUG - 2024-10-26 04:25:31 --> No URI present. Default controller set.
INFO - 2024-10-26 04:25:31 --> Router Class Initialized
INFO - 2024-10-26 04:25:31 --> Output Class Initialized
INFO - 2024-10-26 04:25:31 --> Security Class Initialized
DEBUG - 2024-10-26 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:25:31 --> Input Class Initialized
INFO - 2024-10-26 04:25:31 --> Language Class Initialized
INFO - 2024-10-26 04:25:31 --> Loader Class Initialized
DEBUG - 2024-10-26 04:25:31 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:25:31 --> Helper loaded: security_helper
INFO - 2024-10-26 04:25:31 --> Helper loaded: form_helper
INFO - 2024-10-26 04:25:31 --> Helper loaded: url_helper
INFO - 2024-10-26 04:25:31 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:25:31 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:25:31 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:25:31 --> Database Driver Class Initialized
INFO - 2024-10-26 04:25:31 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:25:31 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:25:31 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:25:31 --> Email Class Initialized
INFO - 2024-10-26 04:25:31 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:25:31 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:25:31 --> Helper loaded: language_helper
INFO - 2024-10-26 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:25:31 --> Model Class Initialized
INFO - 2024-10-26 04:25:31 --> Helper loaded: date_helper
INFO - 2024-10-26 04:25:31 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:25:31 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:25:31 --> Migrations Class Initialized
INFO - 2024-10-26 04:25:31 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:25:31 --> Database Forge Class Initialized
INFO - 2024-10-26 04:25:31 --> Controller Class Initialized
INFO - 2024-10-26 04:25:31 --> Model Class Initialized
INFO - 2024-10-26 04:25:31 --> Model Class Initialized
INFO - 2024-10-26 04:25:31 --> Model Class Initialized
INFO - 2024-10-26 04:25:31 --> Model Class Initialized
ERROR - 2024-10-26 04:25:31 --> Severity: error --> Exception: Call to undefined method Demandas_model::get_demandas_encerradas_com_sucesso_por_mes() /Applications/MAMP/htdocs/credito/application/controllers/Dashboard.php 29
INFO - 2024-10-26 04:26:22 --> Config Class Initialized
INFO - 2024-10-26 04:26:22 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:26:22 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:26:22 --> Utf8 Class Initialized
INFO - 2024-10-26 04:26:22 --> URI Class Initialized
DEBUG - 2024-10-26 04:26:22 --> No URI present. Default controller set.
INFO - 2024-10-26 04:26:22 --> Router Class Initialized
INFO - 2024-10-26 04:26:22 --> Output Class Initialized
INFO - 2024-10-26 04:26:22 --> Security Class Initialized
DEBUG - 2024-10-26 04:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:26:22 --> Input Class Initialized
INFO - 2024-10-26 04:26:22 --> Language Class Initialized
INFO - 2024-10-26 04:26:22 --> Loader Class Initialized
DEBUG - 2024-10-26 04:26:22 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:26:22 --> Helper loaded: security_helper
INFO - 2024-10-26 04:26:22 --> Helper loaded: form_helper
INFO - 2024-10-26 04:26:22 --> Helper loaded: url_helper
INFO - 2024-10-26 04:26:22 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:26:22 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:26:22 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:26:22 --> Database Driver Class Initialized
INFO - 2024-10-26 04:26:22 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:26:22 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:26:22 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:26:22 --> Email Class Initialized
INFO - 2024-10-26 04:26:22 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:26:22 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:26:22 --> Helper loaded: language_helper
INFO - 2024-10-26 04:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:26:22 --> Model Class Initialized
INFO - 2024-10-26 04:26:22 --> Helper loaded: date_helper
INFO - 2024-10-26 04:26:22 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:26:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:26:22 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:26:22 --> Migrations Class Initialized
INFO - 2024-10-26 04:26:22 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:26:22 --> Database Forge Class Initialized
INFO - 2024-10-26 04:26:22 --> Controller Class Initialized
INFO - 2024-10-26 04:26:22 --> Model Class Initialized
INFO - 2024-10-26 04:26:22 --> Model Class Initialized
INFO - 2024-10-26 04:26:22 --> Model Class Initialized
INFO - 2024-10-26 04:26:22 --> Model Class Initialized
INFO - 2024-10-26 05:26:22 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 05:26:22 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 05:26:22 --> Final output sent to browser
DEBUG - 2024-10-26 05:26:22 --> Total execution time: 0.0982
INFO - 2024-10-26 04:26:36 --> Config Class Initialized
INFO - 2024-10-26 04:26:36 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:26:36 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:26:36 --> Utf8 Class Initialized
INFO - 2024-10-26 04:26:36 --> URI Class Initialized
DEBUG - 2024-10-26 04:26:36 --> No URI present. Default controller set.
INFO - 2024-10-26 04:26:36 --> Router Class Initialized
INFO - 2024-10-26 04:26:36 --> Output Class Initialized
INFO - 2024-10-26 04:26:36 --> Security Class Initialized
DEBUG - 2024-10-26 04:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:26:36 --> Input Class Initialized
INFO - 2024-10-26 04:26:36 --> Language Class Initialized
INFO - 2024-10-26 04:26:36 --> Loader Class Initialized
DEBUG - 2024-10-26 04:26:36 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:26:36 --> Helper loaded: security_helper
INFO - 2024-10-26 04:26:36 --> Helper loaded: form_helper
INFO - 2024-10-26 04:26:36 --> Helper loaded: url_helper
INFO - 2024-10-26 04:26:36 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:26:36 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:26:36 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:26:36 --> Database Driver Class Initialized
INFO - 2024-10-26 04:26:36 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:26:36 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:26:36 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:26:36 --> Email Class Initialized
INFO - 2024-10-26 04:26:36 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:26:36 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:26:36 --> Helper loaded: language_helper
INFO - 2024-10-26 04:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:26:36 --> Model Class Initialized
INFO - 2024-10-26 04:26:36 --> Helper loaded: date_helper
INFO - 2024-10-26 04:26:36 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:26:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:26:36 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:26:36 --> Migrations Class Initialized
INFO - 2024-10-26 04:26:36 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:26:36 --> Database Forge Class Initialized
INFO - 2024-10-26 04:26:36 --> Controller Class Initialized
INFO - 2024-10-26 04:26:36 --> Model Class Initialized
INFO - 2024-10-26 04:26:36 --> Model Class Initialized
INFO - 2024-10-26 04:26:36 --> Model Class Initialized
INFO - 2024-10-26 04:26:36 --> Model Class Initialized
INFO - 2024-10-26 05:26:36 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 05:26:36 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 05:26:36 --> Final output sent to browser
DEBUG - 2024-10-26 05:26:36 --> Total execution time: 0.0815
INFO - 2024-10-26 04:27:13 --> Config Class Initialized
INFO - 2024-10-26 04:27:13 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:27:13 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:27:13 --> Utf8 Class Initialized
INFO - 2024-10-26 04:27:13 --> URI Class Initialized
INFO - 2024-10-26 04:27:13 --> Router Class Initialized
INFO - 2024-10-26 04:27:13 --> Output Class Initialized
INFO - 2024-10-26 04:27:13 --> Security Class Initialized
DEBUG - 2024-10-26 04:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:27:13 --> Input Class Initialized
INFO - 2024-10-26 04:27:13 --> Language Class Initialized
ERROR - 2024-10-26 04:27:13 --> 404 Page Not Found: Resources/css
INFO - 2024-10-26 04:27:44 --> Config Class Initialized
INFO - 2024-10-26 04:27:44 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:27:44 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:27:44 --> Utf8 Class Initialized
INFO - 2024-10-26 04:27:44 --> URI Class Initialized
DEBUG - 2024-10-26 04:27:44 --> No URI present. Default controller set.
INFO - 2024-10-26 04:27:44 --> Router Class Initialized
INFO - 2024-10-26 04:27:44 --> Output Class Initialized
INFO - 2024-10-26 04:27:44 --> Security Class Initialized
DEBUG - 2024-10-26 04:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:27:44 --> Input Class Initialized
INFO - 2024-10-26 04:27:44 --> Language Class Initialized
INFO - 2024-10-26 04:27:44 --> Loader Class Initialized
DEBUG - 2024-10-26 04:27:44 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:27:44 --> Helper loaded: security_helper
INFO - 2024-10-26 04:27:44 --> Helper loaded: form_helper
INFO - 2024-10-26 04:27:44 --> Helper loaded: url_helper
INFO - 2024-10-26 04:27:44 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:27:44 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:27:44 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:27:44 --> Database Driver Class Initialized
INFO - 2024-10-26 04:27:44 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:27:44 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:27:44 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:27:44 --> Email Class Initialized
INFO - 2024-10-26 04:27:44 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:27:44 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:27:44 --> Helper loaded: language_helper
INFO - 2024-10-26 04:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:27:44 --> Model Class Initialized
INFO - 2024-10-26 04:27:44 --> Helper loaded: date_helper
INFO - 2024-10-26 04:27:44 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:27:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:27:44 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:27:44 --> Migrations Class Initialized
INFO - 2024-10-26 04:27:44 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:27:44 --> Database Forge Class Initialized
INFO - 2024-10-26 04:27:44 --> Controller Class Initialized
INFO - 2024-10-26 04:27:44 --> Model Class Initialized
INFO - 2024-10-26 04:27:44 --> Model Class Initialized
INFO - 2024-10-26 04:27:44 --> Model Class Initialized
INFO - 2024-10-26 04:27:44 --> Model Class Initialized
INFO - 2024-10-26 05:27:44 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 05:27:44 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 05:27:44 --> Final output sent to browser
DEBUG - 2024-10-26 05:27:44 --> Total execution time: 0.0998
INFO - 2024-10-26 04:30:12 --> Config Class Initialized
INFO - 2024-10-26 04:30:12 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:30:12 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:30:12 --> Utf8 Class Initialized
INFO - 2024-10-26 04:30:12 --> URI Class Initialized
DEBUG - 2024-10-26 04:30:12 --> No URI present. Default controller set.
INFO - 2024-10-26 04:30:12 --> Router Class Initialized
INFO - 2024-10-26 04:30:12 --> Output Class Initialized
INFO - 2024-10-26 04:30:12 --> Security Class Initialized
DEBUG - 2024-10-26 04:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:30:12 --> Input Class Initialized
INFO - 2024-10-26 04:30:12 --> Language Class Initialized
INFO - 2024-10-26 04:30:12 --> Loader Class Initialized
DEBUG - 2024-10-26 04:30:12 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:30:12 --> Helper loaded: security_helper
INFO - 2024-10-26 04:30:12 --> Helper loaded: form_helper
INFO - 2024-10-26 04:30:12 --> Helper loaded: url_helper
INFO - 2024-10-26 04:30:12 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:30:12 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:30:12 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:30:12 --> Database Driver Class Initialized
INFO - 2024-10-26 04:30:12 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:30:12 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:30:12 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:30:12 --> Email Class Initialized
INFO - 2024-10-26 04:30:12 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:30:12 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:30:12 --> Helper loaded: language_helper
INFO - 2024-10-26 04:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:30:12 --> Model Class Initialized
INFO - 2024-10-26 04:30:12 --> Helper loaded: date_helper
INFO - 2024-10-26 04:30:12 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:30:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:30:12 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:30:12 --> Migrations Class Initialized
INFO - 2024-10-26 04:30:12 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:30:12 --> Database Forge Class Initialized
INFO - 2024-10-26 04:30:12 --> Controller Class Initialized
INFO - 2024-10-26 04:30:12 --> Model Class Initialized
INFO - 2024-10-26 04:30:12 --> Model Class Initialized
INFO - 2024-10-26 04:30:12 --> Model Class Initialized
INFO - 2024-10-26 04:30:12 --> Model Class Initialized
INFO - 2024-10-26 05:30:12 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 05:30:12 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 05:30:12 --> Final output sent to browser
DEBUG - 2024-10-26 05:30:12 --> Total execution time: 0.1092
INFO - 2024-10-26 04:30:12 --> Config Class Initialized
INFO - 2024-10-26 04:30:12 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:30:12 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:30:12 --> Utf8 Class Initialized
INFO - 2024-10-26 04:30:12 --> URI Class Initialized
INFO - 2024-10-26 04:30:12 --> Router Class Initialized
INFO - 2024-10-26 04:30:12 --> Output Class Initialized
INFO - 2024-10-26 04:30:12 --> Security Class Initialized
DEBUG - 2024-10-26 04:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:30:12 --> Input Class Initialized
INFO - 2024-10-26 04:30:12 --> Language Class Initialized
ERROR - 2024-10-26 04:30:12 --> 404 Page Not Found: Resources/css
INFO - 2024-10-26 04:30:20 --> Config Class Initialized
INFO - 2024-10-26 04:30:21 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:30:21 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:30:21 --> Utf8 Class Initialized
INFO - 2024-10-26 04:30:21 --> URI Class Initialized
DEBUG - 2024-10-26 04:30:21 --> No URI present. Default controller set.
INFO - 2024-10-26 04:30:21 --> Router Class Initialized
INFO - 2024-10-26 04:30:21 --> Output Class Initialized
INFO - 2024-10-26 04:30:21 --> Security Class Initialized
DEBUG - 2024-10-26 04:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:30:21 --> Input Class Initialized
INFO - 2024-10-26 04:30:21 --> Language Class Initialized
INFO - 2024-10-26 04:30:21 --> Loader Class Initialized
DEBUG - 2024-10-26 04:30:21 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:30:21 --> Helper loaded: security_helper
INFO - 2024-10-26 04:30:21 --> Helper loaded: form_helper
INFO - 2024-10-26 04:30:21 --> Helper loaded: url_helper
INFO - 2024-10-26 04:30:21 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:30:21 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:30:21 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:30:21 --> Database Driver Class Initialized
INFO - 2024-10-26 04:30:21 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:30:21 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:30:21 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:30:21 --> Email Class Initialized
INFO - 2024-10-26 04:30:21 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:30:21 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:30:21 --> Helper loaded: language_helper
INFO - 2024-10-26 04:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:30:21 --> Model Class Initialized
INFO - 2024-10-26 04:30:21 --> Helper loaded: date_helper
INFO - 2024-10-26 04:30:21 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:30:21 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:30:21 --> Migrations Class Initialized
INFO - 2024-10-26 04:30:21 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:30:21 --> Database Forge Class Initialized
INFO - 2024-10-26 04:30:21 --> Controller Class Initialized
INFO - 2024-10-26 04:30:21 --> Model Class Initialized
INFO - 2024-10-26 04:30:21 --> Model Class Initialized
INFO - 2024-10-26 04:30:21 --> Model Class Initialized
INFO - 2024-10-26 04:30:21 --> Model Class Initialized
INFO - 2024-10-26 05:30:21 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 05:30:21 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 05:30:21 --> Final output sent to browser
DEBUG - 2024-10-26 05:30:21 --> Total execution time: 0.0970
INFO - 2024-10-26 04:30:24 --> Config Class Initialized
INFO - 2024-10-26 04:30:24 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:30:24 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:30:24 --> Utf8 Class Initialized
INFO - 2024-10-26 04:30:24 --> URI Class Initialized
DEBUG - 2024-10-26 04:30:24 --> No URI present. Default controller set.
INFO - 2024-10-26 04:30:24 --> Router Class Initialized
INFO - 2024-10-26 04:30:24 --> Output Class Initialized
INFO - 2024-10-26 04:30:24 --> Security Class Initialized
DEBUG - 2024-10-26 04:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:30:24 --> Input Class Initialized
INFO - 2024-10-26 04:30:24 --> Language Class Initialized
INFO - 2024-10-26 04:30:24 --> Loader Class Initialized
DEBUG - 2024-10-26 04:30:24 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:30:24 --> Helper loaded: security_helper
INFO - 2024-10-26 04:30:24 --> Helper loaded: form_helper
INFO - 2024-10-26 04:30:24 --> Helper loaded: url_helper
INFO - 2024-10-26 04:30:24 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:30:24 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:30:24 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:30:24 --> Database Driver Class Initialized
INFO - 2024-10-26 04:30:24 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:30:24 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:30:24 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:30:24 --> Email Class Initialized
INFO - 2024-10-26 04:30:24 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:30:24 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:30:24 --> Helper loaded: language_helper
INFO - 2024-10-26 04:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:30:24 --> Model Class Initialized
INFO - 2024-10-26 04:30:24 --> Helper loaded: date_helper
INFO - 2024-10-26 04:30:24 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:30:24 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:30:24 --> Migrations Class Initialized
INFO - 2024-10-26 04:30:24 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:30:24 --> Database Forge Class Initialized
INFO - 2024-10-26 04:30:24 --> Controller Class Initialized
INFO - 2024-10-26 04:30:24 --> Model Class Initialized
INFO - 2024-10-26 04:30:24 --> Model Class Initialized
INFO - 2024-10-26 04:30:24 --> Model Class Initialized
INFO - 2024-10-26 04:30:24 --> Model Class Initialized
INFO - 2024-10-26 05:30:24 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 05:30:24 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 05:30:24 --> Final output sent to browser
DEBUG - 2024-10-26 05:30:24 --> Total execution time: 0.0819
INFO - 2024-10-26 04:30:52 --> Config Class Initialized
INFO - 2024-10-26 04:30:52 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:30:52 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:30:52 --> Utf8 Class Initialized
INFO - 2024-10-26 04:30:52 --> URI Class Initialized
DEBUG - 2024-10-26 04:30:52 --> No URI present. Default controller set.
INFO - 2024-10-26 04:30:52 --> Router Class Initialized
INFO - 2024-10-26 04:30:52 --> Output Class Initialized
INFO - 2024-10-26 04:30:52 --> Security Class Initialized
DEBUG - 2024-10-26 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:30:52 --> Input Class Initialized
INFO - 2024-10-26 04:30:52 --> Language Class Initialized
INFO - 2024-10-26 04:30:52 --> Loader Class Initialized
DEBUG - 2024-10-26 04:30:52 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:30:52 --> Helper loaded: security_helper
INFO - 2024-10-26 04:30:52 --> Helper loaded: form_helper
INFO - 2024-10-26 04:30:52 --> Helper loaded: url_helper
INFO - 2024-10-26 04:30:52 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:30:52 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:30:52 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:30:52 --> Database Driver Class Initialized
INFO - 2024-10-26 04:30:52 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:30:52 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:30:52 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:30:52 --> Email Class Initialized
INFO - 2024-10-26 04:30:52 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:30:52 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:30:52 --> Helper loaded: language_helper
INFO - 2024-10-26 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:30:52 --> Model Class Initialized
INFO - 2024-10-26 04:30:52 --> Helper loaded: date_helper
INFO - 2024-10-26 04:30:52 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:30:52 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:30:52 --> Migrations Class Initialized
INFO - 2024-10-26 04:30:52 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:30:52 --> Database Forge Class Initialized
INFO - 2024-10-26 04:30:52 --> Controller Class Initialized
INFO - 2024-10-26 04:30:52 --> Model Class Initialized
INFO - 2024-10-26 04:30:52 --> Model Class Initialized
INFO - 2024-10-26 04:30:52 --> Model Class Initialized
INFO - 2024-10-26 04:30:52 --> Model Class Initialized
INFO - 2024-10-26 05:30:52 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 05:30:52 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 05:30:52 --> Final output sent to browser
DEBUG - 2024-10-26 05:30:52 --> Total execution time: 0.0944
INFO - 2024-10-26 04:31:03 --> Config Class Initialized
INFO - 2024-10-26 04:31:03 --> Hooks Class Initialized
DEBUG - 2024-10-26 04:31:03 --> UTF-8 Support Enabled
INFO - 2024-10-26 04:31:03 --> Utf8 Class Initialized
INFO - 2024-10-26 04:31:03 --> URI Class Initialized
DEBUG - 2024-10-26 04:31:03 --> No URI present. Default controller set.
INFO - 2024-10-26 04:31:03 --> Router Class Initialized
INFO - 2024-10-26 04:31:03 --> Output Class Initialized
INFO - 2024-10-26 04:31:03 --> Security Class Initialized
DEBUG - 2024-10-26 04:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 04:31:03 --> Input Class Initialized
INFO - 2024-10-26 04:31:03 --> Language Class Initialized
INFO - 2024-10-26 04:31:03 --> Loader Class Initialized
DEBUG - 2024-10-26 04:31:03 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/pagination.php
INFO - 2024-10-26 04:31:03 --> Helper loaded: security_helper
INFO - 2024-10-26 04:31:03 --> Helper loaded: form_helper
INFO - 2024-10-26 04:31:03 --> Helper loaded: url_helper
INFO - 2024-10-26 04:31:03 --> Helper loaded: datetime_helper
INFO - 2024-10-26 04:31:03 --> Helper loaded: numbers_helper
INFO - 2024-10-26 04:31:03 --> Helper loaded: strings_helper
INFO - 2024-10-26 04:31:03 --> Database Driver Class Initialized
INFO - 2024-10-26 04:31:03 --> Language file loaded: language/portuguese/pagination_lang.php
INFO - 2024-10-26 04:31:03 --> Pagination Class Initialized
DEBUG - 2024-10-26 04:31:03 --> Config file loaded: /Applications/MAMP/htdocs/credito/application/config/ion_auth.php
INFO - 2024-10-26 04:31:03 --> Email Class Initialized
INFO - 2024-10-26 04:31:03 --> Language file loaded: language/portuguese/ion_auth_lang.php
INFO - 2024-10-26 04:31:03 --> Helper loaded: cookie_helper
INFO - 2024-10-26 04:31:03 --> Helper loaded: language_helper
INFO - 2024-10-26 04:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 04:31:03 --> Model Class Initialized
INFO - 2024-10-26 04:31:03 --> Helper loaded: date_helper
INFO - 2024-10-26 04:31:03 --> Form Validation Class Initialized
DEBUG - 2024-10-26 04:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-10-26 04:31:03 --> Email class already loaded. Second attempt ignored.
INFO - 2024-10-26 04:31:03 --> Migrations Class Initialized
INFO - 2024-10-26 04:31:03 --> Language file loaded: language/portuguese/migration_lang.php
INFO - 2024-10-26 04:31:03 --> Database Forge Class Initialized
INFO - 2024-10-26 04:31:03 --> Controller Class Initialized
INFO - 2024-10-26 04:31:03 --> Model Class Initialized
INFO - 2024-10-26 04:31:03 --> Model Class Initialized
INFO - 2024-10-26 04:31:03 --> Model Class Initialized
INFO - 2024-10-26 04:31:03 --> Model Class Initialized
INFO - 2024-10-26 05:31:03 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/dashboard.php
INFO - 2024-10-26 05:31:03 --> File loaded: /Applications/MAMP/htdocs/credito/application/views/layouts/main.php
INFO - 2024-10-26 05:31:03 --> Final output sent to browser
DEBUG - 2024-10-26 05:31:03 --> Total execution time: 0.0854
