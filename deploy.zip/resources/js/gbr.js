/*! gbr.js
 * ================
 * Arquivo que irá conter funções gerais disponiveis globalmente para o aplicativo
 *
 * @Author  Moisés Duarte
 * @Support <http://www.citstamazonas.org.br>
 * @Email   <moises.duarte@citsamazonas.org.br>
 * @version 1.0.0
 * @license All copyrights reserved to CITS Amazonas
 */
